# Project stages — assessment documentation only

The product contains no visible stage labels.

The first build includes auth, adaptive quiz, BMI, estimated maintenance, explicit goals, optional Gemini explanations, searchable meal/macro/fiber tracking, water/sleep tracking and separate 7-/30-day charts inside each core tracker. Overview stays limited to current calories/water/sleep, meal logging and a daily quote. Roadmap navigation is removed.

The second build adds workouts/planning, private journaling and a combined progress report. Both share modular source and persistent records. Internal PROJECT_PHASE and VITE_PROJECT_PHASE settings must match (1 or 2). The archives preconfigure their respective defaults; these labels appear in configuration/documentation only.
