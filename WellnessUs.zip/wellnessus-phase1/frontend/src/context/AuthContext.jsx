import { createContext, useContext, useEffect, useState } from 'react';
import { api, message } from '../services/api';
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState('');
  const refresh = async () => {
    try {
      const { data } = await api.get('/auth/me');
      setUser(data.data);
      setError('');
    } catch (e) {
      if (e.response?.status === 401) {
        setUser(null);
        setError('');
      } else setError(message(e));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    refresh();
  }, []);
  useEffect(() => {
    const signedOut = () => setUser(null);
    window.addEventListener('wellnessus:unauthorized', signedOut);
    return () => window.removeEventListener('wellnessus:unauthorized', signedOut);
  }, []);
  return (
    <AuthContext.Provider value={{ user, setUser, refresh, loading, error }}>
      {children}
    </AuthContext.Provider>
  );
}
export const useAuth = () => useContext(AuthContext);
