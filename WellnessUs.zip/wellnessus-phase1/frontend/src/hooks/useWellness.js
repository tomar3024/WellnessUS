import { useCallback, useEffect, useState } from 'react';
import { api, allRecords, message } from '../services/api';
import { PHASE2 } from '../utils/phase';
export const modules = PHASE2
  ? ['meals', 'water', 'sleep', 'workouts', 'journal']
  : ['meals', 'water', 'sleep'];
export function useWellness() {
  const [data, setData] = useState(null),
    [error, setError] = useState(''),
    [refreshing, setRefreshing] = useState(false);
  const reload = useCallback(async () => {
    setRefreshing(true);
    try {
      const [profile, goals, foods, plan, ...records] = await Promise.all([
        api.get('/profile'),
        api.get('/goals'),
        api.get('/foods'),
        api.get('/nutrition-plan'),
        ...modules.map(allRecords),
      ]);
      setData({
        profile: profile.data.data,
        goals: goals.data.data,
        foods: foods.data.data,
        plan: plan.data.data,
        ...Object.fromEntries(modules.map((m, i) => [m, records[i]])),
      });
      setError('');
    } catch (e) {
      setError(message(e));
    } finally {
      setRefreshing(false);
    }
  }, []);
  useEffect(() => {
    reload();
  }, [reload]);
  return { data, error, reload, refreshing };
}
