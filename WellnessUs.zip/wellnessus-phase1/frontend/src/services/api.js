import axios from 'axios';
export const api = axios.create({
  baseURL: `${import.meta.env.VITE_API_URL || ''}/api`,
  withCredentials: true,
  timeout: 15000,
});
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && !error.config?.url?.includes('/auth/login'))
      window.dispatchEvent(new Event('wellnessus:unauthorized'));
    return Promise.reject(error);
  },
);
export const message = (e) =>
  e.response?.data?.error ||
  (e.code === 'ECONNABORTED'
    ? 'The request took too long. Please try again.'
    : 'Unable to connect. Check that the server is running.');
export async function allRecords(module) {
  let data = [],
    page = 1,
    total;
  do {
    const response = (await api.get(`/${module}`, { params: { page, limit: 500 } })).data;
    data.push(...response.data);
    total = response.total;
    page++;
  } while (data.length < total);
  return data;
}
