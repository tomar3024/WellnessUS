import { useCallback, useState } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { useWellness } from './hooks/useWellness';
import { api, message } from './services/api';
import { timeZone } from './utils/dates';
import { PHASE2 } from './utils/phase';

import Shell from './layouts/Shell';
import Auth from './pages/Auth';
import Profile, { Onboarding } from './pages/Profile';
import Dashboard from './pages/Dashboard';
import Tracker from './pages/Tracker';
import ProgressPage from './pages/Progress';
import Settings from './pages/Settings';
import { Modal, Brand } from './components/UI';
import RecordForm, { FoodForm } from './components/RecordForm';
export default function App() {
  const auth = useAuth();
  if (auth.loading)
    return (
      <div className="loading-page">
        <Brand />
        <p>Opening your wellness space…</p>
      </div>
    );
  if (auth.error)
    return (
      <div className="loading-page">
        <Brand />
        <p className="error" role="alert">
          {auth.error}
        </p>
        <button className="button" onClick={auth.refresh}>
          Try again
        </button>
      </div>
    );
  if (!auth.user)
    return (
      <Routes>
        <Route path="/login" element={<Auth />} />
        <Route path="/register" element={<Auth register />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  if (!auth.user.onboarded)
    return (
      <Routes>
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="*" element={<Navigate to="/onboarding" replace />} />
      </Routes>
    );
  return <Workspace />;
}
function Workspace() {
  const { data, error, reload, refreshing } = useWellness();
  const { setUser } = useAuth();
  const [modal, setModal] = useState(null),
    [notice, setNotice] = useState(''),
    [actionError, setActionError] = useState(''),
    [waterBusy, setWaterBusy] = useState(false),
    [deleting, setDeleting] = useState(false),
    [logoutBusy, setLogoutBusy] = useState(false);
  const close = useCallback(() => setModal(null), []);
  function open(module, record = null, date) {
    setModal({ module, record, date });
  }
  async function saved() {
    close();
    await reload();
    setNotice('Your entry has been saved.');
  }
  async function addWater(amount) {
    if (waterBusy) return;
    setWaterBusy(true);
    setActionError('');
    try {
      await api.post('/water', { amount, timeZone: timeZone() });
      await reload();
      setNotice(`${amount} ml of water added.`);
    } catch (e) {
      setActionError(message(e));
    } finally {
      setWaterBusy(false);
    }
  }
  async function confirmDelete() {
    setDeleting(true);
    setActionError('');
    try {
      await api.delete(`/${modal.module}/${modal.record._id}`);
      close();
      await reload();
      setNotice('Entry deleted.');
    } catch (e) {
      setActionError(message(e));
    } finally {
      setDeleting(false);
    }
  }
  async function logout() {
    setLogoutBusy(true);
    try {
      await api.post('/auth/logout');
      setUser(null);
    } catch (e) {
      setActionError(message(e));
    } finally {
      setLogoutBusy(false);
    }
  }
  const shared = {
    data,
    open,
    remove: (module, record) => setModal({ module, record, delete: true }),
    addWater,
    waterBusy,
    customFood: () => setModal({ food: true }),
  };
  return (
    <Shell logout={logout} logoutBusy={logoutBusy}>
      {notice && (
        <div className="notice" role="status">
          {notice}
          <button onClick={() => setNotice('')} aria-label="Dismiss notification">
            ×
          </button>
        </div>
      )}
      {(error || actionError) && (
        <div className="error" role="alert">
          {error || actionError}
          <button
            className="text-button"
            onClick={() => {
              setActionError('');
              reload();
            }}
          >
            Retry
          </button>
        </div>
      )}
      {!data ? (
        <div className="loading-page">
          <p>{refreshing ? 'Loading your saved records…' : 'Your records could not be loaded.'}</p>
        </div>
      ) : (
        <Routes>
          <Route path="/" element={<Dashboard {...shared} />} />
          <Route path="/profile" element={<Profile data={data} reload={reload} />} />
          {[
            ['nutrition', 'meals'],
            ['hydration', 'water'],
            ['sleep', 'sleep'],
            ...(PHASE2
              ? [
                  ['workouts', 'workouts'],
                  ['journal', 'journal'],
                ]
              : []),
          ].map(([path, module]) => (
            <Route
              key={path}
              path={`/${path}`}
              element={<Tracker key={module} module={module} {...shared} />}
            />
          ))}
          {PHASE2 && <Route path="/progress" element={<ProgressPage {...shared} />} />}

          <Route path="/settings" element={<Settings data={data} reload={reload} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      )}
      {modal && data && (
        <Modal
          title={
            modal.delete
              ? 'Delete this entry?'
              : modal.food
                ? 'Add a custom food'
                : `${modal.record ? 'Edit' : 'Log'} ${modal.module === 'meals' ? 'meal' : modal.module === 'water' ? 'water' : modal.module === 'weight' ? 'measurement' : modal.module === 'journal' ? 'journal entry' : modal.module === 'workouts' ? 'workout' : 'sleep'}`
          }
          onClose={close}
        >
          {modal.delete ? (
            <>
              <p>This will permanently remove this entry from your account.</p>
              {actionError && (
                <p className="error" role="alert">
                  {actionError}
                </p>
              )}
              <div className="form-actions">
                <button className="button secondary" onClick={close}>
                  Keep entry
                </button>
                <button className="button destructive" disabled={deleting} onClick={confirmDelete}>
                  {deleting ? 'Deleting…' : 'Delete entry'}
                </button>
              </div>
            </>
          ) : modal.food ? (
            <FoodForm onSaved={saved} />
          ) : (
            <RecordForm
              module={modal.module}
              record={modal.record}
              date={modal.date}
              foods={data.foods}
              sleepRecords={data.sleep}
              onSaved={saved}
            />
          )}
        </Modal>
      )}
    </Shell>
  );
}
