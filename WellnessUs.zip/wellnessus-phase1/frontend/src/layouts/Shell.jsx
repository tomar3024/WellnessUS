import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  UserRound,
  Utensils,
  Droplets,
  Moon,
  Dumbbell,
  ChartNoAxesCombined,
  BookOpen,
  Settings,
  LogOut,
  Menu,
  X,
  Compass,
  ChevronRight,
  Clock3,
} from 'lucide-react';
import { Brand } from '../components/UI';
import { useAuth } from '../context/AuthContext';
import { useClock } from '../hooks/useClock';
import { PHASE2 } from '../utils/phase';
const nav = [
  ['/', 'Overview', LayoutDashboard],
  ['/profile', 'Health profile', UserRound],
  ['/nutrition', 'Meals & calories', Utensils],
  ['/hydration', 'Water', Droplets],
  ['/sleep', 'Sleep', Moon],

  ...(PHASE2
    ? [
        ['/workouts', 'Workouts', Dumbbell],
        ['/journal', 'Journal', BookOpen],
        ['/progress', 'Progress', ChartNoAxesCombined],
      ]
    : []),
];
export default function Shell({ children, logout, logoutBusy }) {
  const [menu, setMenu] = useState(false);
  const { user } = useAuth();
  const { now, timeZone } = useClock();
  return (
    <div className="app-shell">
      <header className="mobile-bar">
        <Brand />
        <button
          className="icon-button"
          aria-label={menu ? 'Close navigation' : 'Open navigation'}
          aria-expanded={menu}
          onClick={() => setMenu(!menu)}
        >
          {menu ? <X /> : <Menu />}
        </button>
      </header>
      {menu && (
        <button
          className="sidebar-backdrop"
          aria-label="Close navigation"
          onClick={() => setMenu(false)}
        />
      )}
      <aside className={`sidebar ${menu ? 'open' : ''}`}>
        <Brand />
        <span className="sidebar-caption">YOUR PERSONAL SPACE</span>
        <nav aria-label="Main navigation">
          {nav.map(([to, label, Icon]) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              onClick={() => setMenu(false)}
              className={({ isActive }) => (isActive ? 'active' : '')}
            >
              <Icon size={19} />
              <span>{label}</span>
              <ChevronRight className="nav-chevron" size={14} />
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <span className="live-dot" />
            <strong>
              Built around
              <br />
              your real day.
            </strong>
            <p>Meals. Water. Rest. Repeat.</p>
          </div>
          <NavLink to="/settings" onClick={() => setMenu(false)} className="settings-link">
            <Settings size={19} /> Goals & settings
          </NavLink>
          <div className="user-block">
            <span className="avatar">{user.name.charAt(0).toUpperCase()}</span>
            <div>
              <strong>{user.name}</strong>
              <small>Personal workspace</small>
            </div>
            <button
              className="icon-button"
              disabled={logoutBusy}
              onClick={logout}
              aria-label="Sign out"
            >
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>
      <main className="main-content">
        <div className="topbar">
          <span className="topbar-label">YOUR HEALTH. YOUR RHYTHM.</span>
          <div className="live-clock">
            <Clock3 size={15} />
            <time dateTime={now.toISOString()}>
              {now.toLocaleDateString(undefined, {
                weekday: 'short',
                day: 'numeric',
                month: 'short',
              })}
              <b>
                {now.toLocaleTimeString(undefined, {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                })}
              </b>
            </time>
            <small>{timeZone}</small>
          </div>
        </div>
        <div className="page-content">{children || <Outlet />}</div>
        <footer className="app-footer">
          WELLNESSUS <span>Know your rhythm.</span>
        </footer>
      </main>
    </div>
  );
}
