export const localDate = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const dateLabel = (value) =>
  new Date(`${value}T12:00:00`).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
export function datesBack(days, end = new Date()) {
  return Array.from({ length: days }, (_, i) => {
    const d = new Date(end);
    d.setDate(d.getDate() - days + 1 + i);
    return localDate(d);
  });
}
export const sum = (rows, key) => rows.reduce((a, r) => a + Number(r[key] || 0), 0);
export const round = (n) => Math.round(n * 10) / 10;
export const timeZone = () => Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
export function entryTime(record) {
  const stamp = record.recordedAt || record.createdAt;
  return stamp
    ? new Date(stamp).toLocaleTimeString(undefined, {
        hour: '2-digit',
        minute: '2-digit',
        timeZone: record.timeZone || timeZone(),
      })
    : 'Time unavailable';
}
export function suggestedMeal(now = new Date()) {
  const hour = now.getHours();
  return hour >= 5 && hour < 11
    ? 'Breakfast'
    : hour >= 11 && hour < 16
      ? 'Lunch'
      : hour >= 18 && hour < 22
        ? 'Dinner'
        : 'Snacks';
}
export function dailyQuote(now = new Date()) {
  const quotes = [
    {
      text: 'While we are postponing, life speeds by.',
      author: 'Seneca',
      work: 'Moral Letters, I',
      url: 'https://en.wikisource.org/wiki/Page:Ad_Lucilium_epistulae_morales,_volume_1.djvu/27',
    },
    {
      text: 'Some things are in our control and others not.',
      author: 'Epictetus',
      work: 'Enchiridion, I',
      url: 'https://www.gutenberg.org/files/45109/45109-h/45109-h.htm',
    },
    {
      text: 'If it be not fitting, do it not. If it be not true, speak it not.',
      author: 'Marcus Aurelius',
      work: 'Meditations, XII',
      url: 'https://www.gutenberg.org/files/2680/2680-h/2680-h.htm',
    },
    {
      text: 'Let whatever appears to be the best be to you an inviolable law.',
      author: 'Epictetus',
      work: 'Enchiridion, LI',
      url: 'https://www.gutenberg.org/files/45109/45109-h/45109-h.htm',
    },
  ];
  const day = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000);
  return quotes[((day % quotes.length) + quotes.length) % quotes.length];
}
