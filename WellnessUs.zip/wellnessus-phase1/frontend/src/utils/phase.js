// Phase 1: health profile + core trackers. Phase 2 adds workouts, journal and trends.
export const PHASE2 = import.meta.env.VITE_PROJECT_PHASE === '2';
