import { useState, useEffect } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Field } from './UI';
import { api, message } from '../services/api';
import { localDate, timeZone, suggestedMeal, entryTime, dateLabel } from '../utils/dates';
import { useClock } from '../hooks/useClock';
import { assertSleepDay } from '../utils/sleepLimits';
const foodKeys = ['name', 'serving', 'calories', 'protein', 'carbs', 'fat', 'fiber'];
export function FoodForm({ onSaved }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    const data = Object.fromEntries(new FormData(e.currentTarget));
    for (const key of ['calories', 'protein', 'carbs', 'fat', 'fiber'])
      data[key] = data[key] === '' ? null : Number(data[key]);
    try {
      await api.post('/foods', data);
      await onSaved();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit}>
      <p className="muted">Enter values per serving from the label or your best estimate.</p>
      <div className="form-grid">
        {foodKeys.map((k) => (
          <Field
            key={k}
            label={`${k[0].toUpperCase() + k.slice(1)}${['protein', 'carbs', 'fat', 'fiber'].includes(k) ? ' (g)' : k === 'calories' ? ' (kcal)' : ''}`}
          >
            <input
              name={k}
              required={k !== 'fiber'}
              type={['name', 'serving'].includes(k) ? 'text' : 'number'}
              min="0"
              max={k === 'calories' ? 10000 : 1000}
              step="0.1"
              maxLength={k === 'name' ? 100 : 80}
              placeholder={k === 'fiber' ? 'Unknown (optional)' : undefined}
            />
          </Field>
        ))}
      </div>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
      <button className="button" disabled={busy}>
        {busy ? 'Saving…' : 'Save custom food'}
      </button>
    </form>
  );
}
export default function RecordForm({
  module,
  record,
  foods,
  onSaved,
  date: selectedDate,
  sleepRecords = [],
}) {
  const clock = useClock();
  const automatic = ['meals', 'water'].includes(module);
  const [items, setItems] = useState(record?.items?.map((i) => ({ ...i })) || []),
    [foodId, setFoodId] = useState(''),
    [search, setSearch] = useState('');
  const [exercises, setExercises] = useState(record?.exercises || []),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const [foundFoods, setFoundFoods] = useState(null),
    [searching, setSearching] = useState(false),
    [searchNote, setSearchNote] = useState('');
  const choices =
    foundFoods || foods.filter((f) => f.name.toLowerCase().includes(search.toLowerCase()));
  useEffect(() => {
    if (module !== 'meals' || search.trim().length < 2) {
      setFoundFoods(null);
      setSearchNote('');
      setSearching(false);
      return;
    }
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setSearching(true);
      try {
        const result = (
          await api.get('/foods/search', {
            params: { q: search.trim() },
            signal: controller.signal,
          })
        ).data;
        setFoundFoods(result.data);
        setSearchNote(
          result.warning ||
            (result.onlineConfigured
              ? 'Saved library + USDA FoodData Central · values per stated serving.'
              : 'Searching your saved food library. Add a custom food if yours is missing.'),
        );
      } catch (e) {
        if (e.code !== 'ERR_CANCELED') {
          setFoundFoods(null);
          setSearchNote(
            'Online search is unavailable. Your saved food library is still searchable.',
          );
        }
      } finally {
        if (!controller.signal.aborted) setSearching(false);
      }
    }, 300);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [search, module]);
  const numeric = (name, label, min, max, step = 1, fallback) => (
    <Field label={label}>
      <input
        required
        name={name}
        type="number"
        min={min}
        max={max}
        step={step}
        defaultValue={record?.[name] ?? fallback}
      />
    </Field>
  );
  const select = (name, label, values) => (
    <Field label={label}>
      <select
        name={name}
        defaultValue={
          record?.[name] || (module === 'meals' && name === 'type' ? suggestedMeal() : values[0])
        }
      >
        {values.map((v) => (
          <option key={v}>{v}</option>
        ))}
      </select>
    </Field>
  );
  async function submit(e) {
    e.preventDefault();
    setError('');
    const data = Object.fromEntries(new FormData(e.currentTarget));
    if (automatic) {
      delete data.date;
      data.timeZone = timeZone();
    }
    if (module === 'meals') {
      if (!items.length) return setError('Add at least one food to this meal.');
      data.items = items.map((i) =>
        Object.fromEntries([...foodKeys, 'quantity'].map((k) => [k, i[k]])),
      );
    }
    if (module === 'workouts') data.exercises = exercises;
    for (const key of ['amount', 'duration', 'weight'])
      if (key in data) data[key] = Number(data[key]);
    if (module === 'sleep') {
      try {
        assertSleepDay(sleepRecords, data, record?._id);
      } catch (e) {
        setError(e.message);
        return;
      }
    }
    setBusy(true);
    try {
      if (record) await api.put(`/${module}/${record._id}`, data);
      else await api.post(`/${module}`, data);
      await onSaved();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit}>
      {automatic ? (
        <div className="auto-stamp">
          <span className="live-dot" />
          <div>
            <strong>{record ? 'Original logging time' : 'Logging right now'}</strong>
            <p>
              {record
                ? `${dateLabel(record.date)} · ${entryTime(record)}`
                : `${clock.now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })} · ${clock.now.toLocaleTimeString()}`}
              <small>{record?.timeZone || clock.timeZone}</small>
            </p>
            <small>
              {record
                ? 'Editing keeps the original date and time.'
                : 'Date and time are captured automatically when you save.'}
            </small>
          </div>
        </div>
      ) : (
        <Field label={module === 'sleep' ? 'Wake-up date' : 'Date'}>
          <input
            type="date"
            name="date"
            required
            defaultValue={record?.date || selectedDate || localDate()}
          />
        </Field>
      )}
      {module === 'water' && numeric('amount', 'Water (ml)', 1, 5000, 1, 250)}
      {module === 'weight' && (
        <>
          {numeric('weight', 'Weight (kg)', 10, 500, 0.1)}
          <p className="muted">
            An optional measurement. Changes are shown neutrally, without success or failure labels.
          </p>
        </>
      )}
      {module === 'sleep' && (
        <>
          <div className="form-grid">
            <Field label="Bedtime">
              <input
                type="time"
                name="bedtime"
                required
                defaultValue={record?.bedtime || '22:30'}
              />
            </Field>
            <Field label="Wake-up time">
              <input
                type="time"
                name="wakeTime"
                required
                defaultValue={record?.wakeTime || '06:30'}
              />
            </Field>
          </div>
          <p className="muted">
            If wake time is earlier than bedtime, it is treated as the following morning. You can
            save two sessions per wake-up date, with no more than 24 hours combined.
          </p>
        </>
      )}
      {module === 'meals' && (
        <>
          {select('type', 'Meal', ['Breakfast', 'Lunch', 'Dinner', 'Snacks'])}
          <Field label="Search your food library">
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setFoodId('');
                setFoundFoods(null);
              }}
              placeholder="Try dal, oats or paneer"
            />
          </Field>
          <div className="food-picker">
            <select
              aria-label="Choose food"
              value={foodId}
              onChange={(e) => setFoodId(e.target.value)}
            >
              <option value="">Select a food & serving…</option>
              {choices.map((f) => (
                <option value={f._id} key={f._id}>
                  {f.name} · {f.serving}
                </option>
              ))}
            </select>
            <button
              className="button secondary"
              type="button"
              disabled={!foodId}
              onClick={() => {
                const food = choices.find((f) => f._id === foodId);
                if (!food) {
                  setError('Select a food from the current results.');
                  return;
                }
                setItems([
                  ...items,
                  { ...Object.fromEntries(foodKeys.map((k) => [k, food[k]])), quantity: 1 },
                ]);
                setFoodId('');
              }}
            >
              <Plus size={16} />
              Add
            </button>
          </div>
          {(searching || searchNote) && (
            <p className="food-search-note" role="status">
              {searching ? 'Searching foods…' : searchNote}
            </p>
          )}
          {!foods.length && (
            <p className="muted">
              No foods yet. Close this dialog and add a custom food, or run the documented food seed
              command.
            </p>
          )}
          <div className="meal-items">
            {items.map((item, index) => (
              <div className="meal-item" key={index}>
                <div>
                  <strong>{item.name}</strong>
                  <small>
                    {item.serving} · {Math.round(item.calories * item.quantity)} kcal ·{' '}
                    {Math.round(item.protein * item.quantity * 10) / 10} g protein ·{' '}
                    {item.fiber == null
                      ? 'fiber unknown'
                      : `${Math.round(item.fiber * item.quantity * 10) / 10} g fiber`}
                  </small>
                </div>
                <Field label="Servings">
                  <input
                    type="number"
                    min="0.01"
                    max="100"
                    step="0.01"
                    required
                    value={item.quantity}
                    onChange={(e) =>
                      setItems(
                        items.map((v, i) =>
                          i === index ? { ...v, quantity: Number(e.target.value) } : v,
                        ),
                      )
                    }
                  />
                </Field>
                <button
                  className="icon-button"
                  type="button"
                  aria-label={`Remove ${item.name}`}
                  onClick={() => setItems(items.filter((_, i) => i !== index))}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
          <p className="muted">
            Nutrition values are estimates. Totals are calculated from servings.
          </p>
        </>
      )}
      {module === 'workouts' && (
        <>
          {select('type', 'Workout type', [
            'Strength',
            'Walking',
            'Running',
            'Cycling',
            'Yoga',
            'Swimming',
            'Other',
          ])}
          {numeric('duration', 'Duration (minutes)', 1, 600)}
          <div className="inline-heading">
            <h3>
              Exercises <small>(optional)</small>
            </h3>
            <button
              className="text-button"
              type="button"
              onClick={() => setExercises([...exercises, { name: '', sets: 1, reps: 10 }])}
            >
              <Plus size={15} /> Add exercise
            </button>
          </div>
          {exercises.map((ex, i) => (
            <div className="exercise-row" key={i}>
              <Field label="Exercise">
                <input
                  required
                  maxLength={100}
                  value={ex.name}
                  onChange={(e) =>
                    setExercises(
                      exercises.map((v, n) => (n === i ? { ...v, name: e.target.value } : v)),
                    )
                  }
                />
              </Field>
              {['sets', 'reps'].map((k) => (
                <Field key={k} label={k}>
                  <input
                    type="number"
                    required
                    min="1"
                    max={k === 'sets' ? 100 : 1000}
                    value={ex[k]}
                    onChange={(e) =>
                      setExercises(
                        exercises.map((v, n) =>
                          n === i ? { ...v, [k]: Number(e.target.value) } : v,
                        ),
                      )
                    }
                  />
                </Field>
              ))}
              <button
                type="button"
                className="icon-button"
                aria-label={`Remove exercise ${i + 1}`}
                onClick={() => setExercises(exercises.filter((_, n) => n !== i))}
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </>
      )}
      {module === 'journal' && (
        <>
          {select('mood', 'How are you feeling?', ['Great', 'Good', 'Okay', 'Low', 'Difficult'])}
          <Field label="Title">
            <input
              name="title"
              required
              maxLength={150}
              defaultValue={record?.title}
              placeholder="A moment from today"
            />
          </Field>
          <Field label="Your entry">
            <textarea
              name="content"
              required
              maxLength={20000}
              rows="8"
              defaultValue={record?.content}
              placeholder="What is on your mind?"
            />
          </Field>
        </>
      )}
      {['sleep', 'workouts'].includes(module) && (
        <Field label="Notes (optional)">
          <textarea name="notes" rows="3" maxLength={3000} defaultValue={record?.notes} />
        </Field>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <div className="form-actions">
        <button className="button" disabled={busy}>
          {busy ? 'Saving…' : record ? 'Save changes' : 'Save entry'}
        </button>
      </div>
    </form>
  );
}
