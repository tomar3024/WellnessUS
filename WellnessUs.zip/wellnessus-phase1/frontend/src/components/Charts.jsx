import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { datesBack, sum, round } from '../utils/dates';
import { useState } from 'react';
import { Card } from './UI';
import { sleepDaySummary } from '../utils/sleepLimits';
export function weekData(data, days = 7) {
  return datesBack(days).map((date) => {
    const rows = (key) => (data[key] || []).filter((r) => r.date === date);
    return {
      date,
      label: new Date(`${date}T12:00:00`).toLocaleDateString(undefined, {
        weekday: 'short',
        day: days > 7 ? 'numeric' : undefined,
      }),
      water: sum(rows('water'), 'amount'),
      sleep: sleepDaySummary(rows('sleep')).valid
        ? round(sleepDaySummary(rows('sleep')).hours)
        : null,
      movement: sum(rows('workouts'), 'duration'),
      meals: rows('meals').length,
      calories: round(rows('meals').reduce((a, m) => a + m.totals.calories, 0)),
      protein: round(rows('meals').reduce((a, m) => a + m.totals.protein, 0)),
      carbs: round(rows('meals').reduce((a, m) => a + m.totals.carbs, 0)),
      fat: round(rows('meals').reduce((a, m) => a + m.totals.fat, 0)),
      fiber: round(rows('meals').reduce((a, m) => a + (m.totals.fiber || 0), 0)),
    };
  });
}
export function TrackingTrends({ data, module }) {
  const [days, setDays] = useState(7);
  const points = weekData(data, days);
  const metrics =
    module === 'meals'
      ? [
          ['calories', 'Calories', 'kcal'],
          ['protein', 'Protein', 'g'],
          ['carbs', 'Carbohydrates', 'g'],
          ['fat', 'Fat', 'g'],
          ['fiber', 'Fiber (known values)', 'g'],
        ]
      : module === 'water'
        ? [['water', 'Water intake', 'ml']]
        : [['sleep', 'Sleep duration', 'hours']];
  return (
    <section className="tracking-trends">
      <div className="card-heading wrap">
        <div>
          <span className="eyebrow">YOUR HISTORY, IN CONTEXT</span>
          <h2>
            {module === 'meals'
              ? 'Nutrition over time'
              : module === 'water'
                ? 'Your hydration rhythm'
                : 'Your sleep rhythm'}
          </h2>
          <p>Saved entries over the last {days} days. Unlogged days show zero logged data.</p>
        </div>
        <div className="segmented">
          {[7, 30].map((n) => (
            <button
              type="button"
              key={n}
              aria-pressed={days === n}
              className={days === n ? 'selected' : ''}
              onClick={() => setDays(n)}
            >
              {n === 7 ? '7 days' : '30 days'}
            </button>
          ))}
        </div>
      </div>
      <div className={`trend-grid ${module === 'meals' ? 'nutrition-trends' : ''}`}>
        {metrics.map(([metric, title, unit]) => (
          <Card key={metric}>
            <div className="card-heading">
              <h3>{title}</h3>
              <span className="trend-unit">{unit} / day</span>
            </div>
            <TrendChart
              points={points}
              metric={metric}
              unit={unit}
              type={module === 'meals' ? 'area' : 'bar'}
            />
          </Card>
        ))}
      </div>
      {module === 'meals' && (
        <p className="graph-note">
          Fiber charts include known fiber only. Older or incomplete food entries may undercount it.
          These are logging trends, not a health score.
        </p>
      )}
    </section>
  );
}
export function TrendChart({
  points,
  metric = 'water',
  color = '#bee4cc',
  unit = 'ml',
  type = 'area',
}) {
  const common = { data: points, margin: { top: 15, right: 12, bottom: 0, left: -20 } };
  const axes = (
    <>
      <CartesianGrid vertical={false} stroke="#30372e" />
      <XAxis
        dataKey="label"
        tickLine={false}
        axisLine={false}
        tick={{ fontSize: 11, fill: '#829087' }}
        minTickGap={18}
      />
      <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#829087' }} />
      <Tooltip
        contentStyle={{
          borderRadius: 12,
          border: '1px solid #3c4435',
          background: '#171e23',
          color: '#f2f6e9',
          fontSize: 12,
        }}
        formatter={(v) => [`${v} ${unit}`, metric]}
      />
    </>
  );
  return (
    <div className="chart" role="img" aria-label={`${metric} history chart, measured in ${unit}`}>
      <ResponsiveContainer width="100%" height="100%">
        {type === 'bar' ? (
          <BarChart {...common}>
            {axes}
            <Bar dataKey={metric} fill={color} radius={[5, 5, 0, 0]} maxBarSize={32} />
          </BarChart>
        ) : type === 'line' ? (
          <LineChart {...common}>
            {axes}
            <Line
              type="monotone"
              dataKey={metric}
              stroke={color}
              strokeWidth={3}
              dot={{ r: 4 }}
              connectNulls={false}
            />
          </LineChart>
        ) : (
          <AreaChart {...common}>
            <defs>
              <linearGradient id={`gradient-${metric}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.23} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            {axes}
            <Area
              type="monotone"
              dataKey={metric}
              stroke={color}
              fill={`url(#gradient-${metric})`}
              strokeWidth={2.5}
            />
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
export function GoalRing({ value, goal, unit, label }) {
  const hasGoal = Number.isFinite(goal) && goal > 0,
    filled = hasGoal ? Math.min(value, goal) : 0;
  const points = hasGoal
    ? [
        { name: 'Logged', value: filled },
        { name: 'Remaining', value: Math.max(goal - filled, 0) },
      ]
    : [{ name: 'No goal set', value: 1 }];
  const pct = hasGoal ? Math.round((value / goal) * 100) : null;
  return (
    <div className="goal-ring">
      <div
        className="ring-chart"
        role="img"
        aria-label={`${label}: ${Math.round(value)} ${unit} logged${hasGoal ? ` of ${goal} ${unit}, ${pct} percent` : ', no goal set'}`}
      >
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={points}
              dataKey="value"
              innerRadius="78%"
              outerRadius="96%"
              startAngle={90}
              endAngle={-270}
              stroke="none"
              paddingAngle={0}
              isAnimationActive={false}
            >
              {points.map((p, i) => (
                <Cell key={p.name} fill={hasGoal && i === 0 ? '#bee4cc' : '#29383d'} />
              ))}
            </Pie>
            {hasGoal && (
              <Tooltip
                contentStyle={{
                  background: '#171e23',
                  border: '1px solid #3c4435',
                  borderRadius: 9,
                  color: '#f2f6e9',
                }}
                formatter={(n) => [`${Math.round(n)} ${unit}`, label]}
              />
            )}
          </PieChart>
        </ResponsiveContainer>
        <div className="ring-center" aria-hidden="true">
          <strong>{Math.round(value).toLocaleString()}</strong>
          <span>{unit} logged</span>
        </div>
      </div>
      <div className="ring-caption">
        {hasGoal ? (
          <>
            <b>{pct}%</b>
            <span>
              of {goal.toLocaleString()} {unit} daily reference
            </span>
          </>
        ) : (
          <span>Set a personal goal to start the ring.</span>
        )}
      </div>
      {hasGoal && value > goal && (
        <p className="ring-note">
          {Math.round(value - goal).toLocaleString()} {unit} above your reference. Logged as it is.
        </p>
      )}
    </div>
  );
}
