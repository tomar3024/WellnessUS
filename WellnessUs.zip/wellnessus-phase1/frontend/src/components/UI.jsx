import { useEffect, useRef, useId } from 'react';
import { X, ArrowUpRight, Leaf } from 'lucide-react';
export function Brand() {
  return (
    <span className="brand">
      <span className="brand-mark">
        <Leaf size={23} />
      </span>
      Wellness<span>Us</span>
      <i />
    </span>
  );
}
export function Card({ children, className = '', ...props }) {
  return (
    <section className={`card ${className}`} {...props}>
      {children}
    </section>
  );
}
export function Empty({ title = 'A fresh start', children, action }) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <Leaf size={23} />
      </span>
      <strong>{title}</strong>
      <p>{children || 'Your saved entries will appear here. Start with one small step today.'}</p>
      {action}
    </div>
  );
}
export function Progress({ value, max, color = 'var(--sage)' }) {
  return (
    <div
      className="progress"
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={Math.max(max, value)}
    >
      <span
        style={{ width: `${Math.min(100, max > 0 ? (value / max) * 100 : 0)}%`, background: color }}
      />
    </div>
  );
}
export function Field({ label, children, hint }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}
export function Modal({ title, onClose, children }) {
  const ref = useRef(null),
    titleId = useId();
  useEffect(() => {
    const element = ref.current;
    element.showModal();
    const cancel = (e) => {
      e.preventDefault();
      onClose();
    };
    element.addEventListener('cancel', cancel);
    return () => {
      element.removeEventListener('cancel', cancel);
      element.close();
    };
  }, [onClose]);
  return (
    <dialog ref={ref} aria-labelledby={titleId} className="modal">
      <div className="modal-head">
        <h2 id={titleId}>{title}</h2>
        <button type="button" className="icon-button" aria-label="Close dialog" onClick={onClose}>
          <X size={20} />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export function SectionTitle({ eyebrow, title, children, action }) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow || 'YOUR EVERYDAY WELLNESS'}</div>
        <h1>{title}</h1>
        {children && <p>{children}</p>}
      </div>
      {action}
    </div>
  );
}
export function Stat({ icon: Icon, label, value, unit, note, tone = 'green', action }) {
  return (
    <Card className={`stat ${tone}`}>
      <div className="stat-top">
        <span className="stat-icon">
          <Icon size={20} />
        </span>
        <span>{label}</span>
        {action && (
          <button className="icon-button" onClick={action} aria-label={`Open ${label}`}>
            <ArrowUpRight size={18} />
          </button>
        )}
      </div>
      <div className="stat-value">
        {value}
        <small>{unit}</small>
      </div>
      <p>{note}</p>
    </Card>
  );
}
