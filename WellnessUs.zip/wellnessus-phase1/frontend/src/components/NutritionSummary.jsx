import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Sparkles } from 'lucide-react';
import { Card, Progress } from './UI';
import { api, message } from '../services/api';
import { round } from '../utils/dates';
export function DailyMacros({ meals, plan }) {
  const complete = meals.every((m) => m.items.every((i) => Number.isFinite(i.fiber)));
  return (
    <>
      <span className="eyebrow">TODAY’S NUTRIENTS</span>
      {[
        ['Protein', 'protein'],
        ['Carbohydrates', 'carbs'],
        ['Fat', 'fat'],
        ['Fiber', 'fiber'],
      ].map(([label, key]) => {
        const value = round(meals.reduce((n, m) => n + (m.totals[key] || 0), 0)),
          ref = plan?.references?.[key];
        return (
          <div className="nutrient-row" key={key}>
            <div>
              <span>
                {label}
                {key === 'fiber' && !complete ? <small>known values only</small> : null}
              </span>
              <strong>
                {value}
                <small>g{ref ? ` / ${ref.target} g reference` : ''}</small>
              </strong>
            </div>
            {ref && <Progress value={value} max={ref.target} />}
            <small>
              {ref
                ? ref.low !== null
                  ? `Adult planning range: ${ref.low}–${ref.high} g at your calorie goal.`
                  : 'General adult fiber reference based on your calorie goal.'
                : 'No personalized reference set.'}
            </small>
          </div>
        );
      })}
      <p className="muted small-note">
        {plan?.references
          ? 'References follow your chosen calorie goal and nutrition focus. They are guides, not an individual prescription.'
          : 'Complete the quiz and choose a calorie reference to see suitable adult nutrient guides.'}{' '}
        {!complete && ' Some foods have no fiber data; unknown does not mean zero.'}
      </p>
    </>
  );
}
export function MealGuidance({ plan }) {
  const [result, setResult] = useState(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  async function explain() {
    setBusy(true);
    setError('');
    try {
      setResult((await api.post('/nutrition-plan/explain', { consent: true })).data.data);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Card className="meal-guidance">
      <div>
        <span className="eyebrow">YOUR ENERGY CONTEXT</span>
        <h2>
          {plan?.estimate
            ? `${plan.estimate.low.toLocaleString()}–${plan.estimate.high.toLocaleString()} kcal`
            : 'Start with your personal context.'}
        </h2>
        <p>
          {plan?.estimate
            ? 'Estimated daily maintenance, before any user-chosen adjustment.'
            : 'Answer the adaptive quiz to see whether an energy estimate is appropriate for you.'}
        </p>
      </div>
      <div>
        <p>
          {plan?.explanation ||
            'Your age, measurements, activity and health context help determine what this app can estimate.'}
        </p>
        <Link className="text-button" to="/profile">
          Review your answers & goals <ArrowUpRight size={14} />
        </Link>
        {plan?.estimate && (
          <div className="ai-explanation">
            <button className="button secondary" onClick={explain} disabled={busy}>
              <Sparkles size={14} />
              {busy ? 'Requesting…' : 'Explain with Gemini'}
            </button>
            <small>
              This sends the derived estimate and approach to Google; no name, email, journal or
              health notes.
            </small>
          </div>
        )}
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        {result && (
          <div className="ai-result">
            <p>{result.summary}</p>
            <small>{result.available ? 'Gemini explanation' : result.reason}</small>
          </div>
        )}
      </div>
      {plan?.references && (
        <p className="reference-note">
          {plan.referenceNote}{' '}
          <a href={plan.referenceSource} target="_blank" rel="noreferrer">
            Reference ranges <ArrowUpRight size={12} />
          </a>
        </p>
      )}
    </Card>
  );
}
export function FoodBreakdown({ meals }) {
  if (!meals.length) return null;
  return (
    <Card className="food-breakdown">
      <div className="card-heading">
        <div>
          <h2>What you’ve logged today</h2>
          <p>Amounts and nutrition are calculated from your servings.</p>
        </div>
      </div>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Food & meal</th>
              <th>Amount</th>
              <th>kcal</th>
              <th>Protein</th>
              <th>Carbs</th>
              <th>Fat</th>
              <th>Fiber</th>
            </tr>
          </thead>
          <tbody>
            {meals.flatMap((m) =>
              m.items.map((i, n) => (
                <tr key={`${m._id}-${n}`}>
                  <td>
                    <strong>{i.name}</strong>
                    <small>{m.type}</small>
                  </td>
                  <td>
                    {i.quantity} × {i.serving}
                  </td>
                  {['calories', 'protein', 'carbs', 'fat', 'fiber'].map((k) => (
                    <td key={k}>
                      {i[k] == null
                        ? 'Unknown'
                        : `${round(i[k] * i.quantity)}${k === 'calories' ? '' : ' g'}`}
                    </td>
                  ))}
                </tr>
              )),
            )}
          </tbody>
        </table>
      </div>
      <p className="small-note muted">
        Food values are estimates. Recipes, labels and preparation vary; unknown fiber remains
        marked unknown.
      </p>
    </Card>
  );
}
