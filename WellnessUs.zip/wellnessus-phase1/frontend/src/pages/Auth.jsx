import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Leaf, Heart, ShieldCheck } from 'lucide-react';
import { Brand, Field } from '../components/UI';
import { api, message } from '../services/api';
import { useAuth } from '../context/AuthContext';
export default function Auth({ register = false }) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const { setUser } = useAuth();
  const navigate = useNavigate();
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const values = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const { data } = await api.post(`/auth/${register ? 'register' : 'login'}`, values);
      setUser(data.data);
      navigate(data.data.onboarded ? '/' : '/onboarding');
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <aside className="auth-story">
        <Brand />
        <div className="auth-copy">
          <span className="pill">
            <Leaf size={14} /> SMALL STEPS. LASTING HABITS.
          </span>
          <h1>
            Your everyday,
            <br />
            <em>in balance.</em>
          </h1>
          <p>
            A little more awareness. A little more consistency. A personal space for the routines
            that help you feel your best.
          </p>
          <div className="botanical">
            <div className="botanical-ring" />
            <Leaf size={125} strokeWidth={0.8} />
            <span>Grow at your own pace.</span>
          </div>
        </div>
        <span className="auth-foot">
          <Heart size={16} /> Made for your wellbeing.
        </span>
      </aside>
      <main className="auth-form">
        <div className="auth-form-inner">
          <span className="eyebrow">WELCOME TO WELLNESSUS</span>
          <h2>{register ? 'Make room for you.' : 'Good to have you back.'}</h2>
          <p>
            {register
              ? 'Create your account and start building everyday habits.'
              : 'Sign in to pick up where you left off.'}
          </p>
          <form onSubmit={submit}>
            {register && (
              <Field label="Your name">
                <input
                  name="name"
                  required
                  maxLength={80}
                  autoComplete="name"
                  placeholder="Alex Morgan"
                />
              </Field>
            )}
            <Field label="Email address">
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder="you@example.com"
              />
            </Field>
            <Field
              label="Password"
              hint={register ? 'At least 10 characters, up to 72 UTF-8 bytes.' : undefined}
            >
              <input
                name="password"
                type="password"
                minLength={register ? 10 : 1}
                maxLength={72}
                required
                autoComplete={register ? 'new-password' : 'current-password'}
              />
            </Field>
            {error && (
              <p className="error" role="alert">
                {error}
              </p>
            )}
            <button className="button full" disabled={busy}>
              {busy ? 'Please wait…' : register ? 'Create account' : 'Sign in'}
              <ArrowRight size={17} />
            </button>
          </form>
          <p className="auth-switch">
            {register ? 'Already have an account?' : 'New to WellnessUs?'}{' '}
            <Link to={register ? '/login' : '/register'}>
              {register ? 'Sign in' : 'Create an account'}
            </Link>
          </p>
          <div className="privacy-note">
            <ShieldCheck size={19} />
            <span>Your wellness records are private to your account.</span>
          </div>
        </div>
      </main>
    </div>
  );
}
