import { Link } from 'react-router-dom';
import { Flame, Droplets, Moon, Plus, ArrowUpRight } from 'lucide-react';
import { Card, SectionTitle } from '../components/UI';
import { GoalRing } from '../components/Charts';
import { sum, round, dailyQuote } from '../utils/dates';
import { useClock } from '../hooks/useClock';
import { useAuth } from '../context/AuthContext';
import { sleepDaySummary } from '../utils/sleepLimits';
export default function Dashboard({ data, open, addWater, waterBusy }) {
  const { user } = useAuth(),
    { now, today } = useClock(),
    meals = data.meals.filter((r) => r.date === today),
    water = sum(
      data.water.filter((r) => r.date === today),
      'amount',
    ),
    sleeps = data.sleep.filter((r) => r.date === today),
    sleepSummary = sleepDaySummary(sleeps),
    sleep = sleepSummary.hours,
    calories = meals.reduce((n, m) => n + m.totals.calories, 0),
    quote = dailyQuote(now);
  const greeting =
    now.getHours() < 12 ? 'Good morning' : now.getHours() < 18 ? 'Good afternoon' : 'Good evening';
  return (
    <>
      <div className="daily-quote">
        <span className="quote-label">A THOUGHT FOR TODAY</span>
        <blockquote>“{quote.text}”</blockquote>
        <a href={quote.url} target="_blank" rel="noreferrer">
          {quote.author}
          <span> · {quote.work}</span>
          <ArrowUpRight size={12} />
        </a>
      </div>
      <SectionTitle
        eyebrow={now
          .toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })
          .toUpperCase()}
        title={`${greeting}, ${user.name.split(' ')[0]}.`}
        action={
          <button className="button" onClick={() => open('meals')}>
            <Plus size={17} />
            Log a meal
          </button>
        }
      >
        A clear view of your day.
      </SectionTitle>
      <div className="daily-rings minimal-overview">
        <Card className="ring-card">
          <div className="card-heading">
            <div className="metric-title">
              <Flame size={19} />
              <h2>Calories</h2>
            </div>
            <Link to="/nutrition" className="icon-button" aria-label="Open meals and calories">
              <ArrowUpRight size={17} />
            </Link>
          </div>
          <GoalRing value={calories} goal={data.goals.calories} unit="kcal" label="Calories" />
          <div className="metric-footer">
            <span>{meals.length} meals logged today</span>
            <Link className="text-button" to="/nutrition">
              Your nutrition <ArrowUpRight size={14} />
            </Link>
          </div>
        </Card>
        <Card className="ring-card">
          <div className="card-heading">
            <div className="metric-title">
              <Droplets size={19} />
              <h2>Water</h2>
            </div>
            <Link to="/hydration" className="icon-button" aria-label="Open water tracker">
              <ArrowUpRight size={17} />
            </Link>
          </div>
          <GoalRing value={water} goal={data.goals.water} unit="ml" label="Water" />
          <div className="water-buttons">
            {[150, 250, 500].map((a) => (
              <button key={a} disabled={waterBusy} onClick={() => addWater(a)}>
                <Plus size={14} />
                {a} ml
              </button>
            ))}
          </div>
        </Card>
        <Card className="sleep-summary overview-sleep">
          <div className="card-heading">
            <div className="metric-title">
              <Moon size={19} />
              <h2>Sleep</h2>
            </div>
            <Link to="/sleep" className="icon-button" aria-label="Open sleep tracker">
              <ArrowUpRight size={17} />
            </Link>
          </div>
          <div className="sleep-number">
            {sleeps.length && sleepSummary.valid ? round(sleep) : '—'}
            <small>hours</small>
          </div>
          <p>
            {!sleepSummary.valid
              ? 'Existing entries exceed the daily limits. Review them in Sleep.'
              : sleeps.length
                ? `${data.goals.sleep} hour personal reference`
                : 'Your last night, ready to log.'}
          </p>
          {sleeps.length > 0 && sleepSummary.valid && (
            <div className="sleep-cycle">
              <span>
                Bedtime<strong>{sleeps[0].bedtime}</strong>
              </span>
              <span className="cycle-line" />
              <span>
                Wake-up<strong>{sleeps[0].wakeTime}</strong>
              </span>
            </div>
          )}
          <button
            className="button secondary"
            disabled={sleeps.length >= 2}
            onClick={() => open('sleep')}
          >
            <Plus size={15} />
            {sleeps.length >= 2 ? '2 sessions logged' : 'Log sleep'}
          </button>
        </Card>
      </div>
    </>
  );
}
