import { useState } from 'react';
import { Card, SectionTitle } from '../components/UI';
import { TrendChart, weekData } from '../components/Charts';
import { round } from '../utils/dates';
export default function ProgressPage({ data }) {
  const [days, setDays] = useState(7),
    points = weekData(data, days),
    sleeps = points.filter((p) => p.sleep > 0),
    tracked = points.filter((p) => p.meals || p.water || p.sleep || p.movement).length;
  return (
    <>
      <SectionTitle
        eyebrow="UNDERSTAND YOUR RHYTHM"
        title="See the bigger picture."
        action={
          <div className="segmented">
            {[7, 30].map((n) => (
              <button key={n} className={days === n ? 'selected' : ''} onClick={() => setDays(n)}>
                {n === 7 ? 'Last 7 days' : 'Last 30 days'}
              </button>
            ))}
          </div>
        }
      >
        Trends in what you log, without a score for how you live.
      </SectionTitle>
      <div className="nutrition-totals">
        {[
          ['Meal logging', points.filter((p) => p.meals).length],
          ['Water logging', points.filter((p) => p.water).length],
          ['Sleep logging', sleeps.length],
          ['Movement', points.filter((p) => p.movement).length],
        ].map(([label, value]) => (
          <Card key={label}>
            <span className="muted">{label}</span>
            <strong>
              {value}
              <small>/ {days} days</small>
            </strong>
          </Card>
        ))}
      </div>
      <div className="tracker-overview">
        {[
          ['calories', 'Daily calories', 'kcal'],
          ['water', 'Water intake', 'ml'],
          ['sleep', 'Sleep duration', 'hours'],
          ['movement', 'Movement time', 'minutes'],
        ].map(([metric, title, unit]) => (
          <Card key={metric}>
            <h2>{title}</h2>
            <TrendChart
              points={points}
              metric={metric}
              unit={unit}
              type={metric === 'sleep' ? 'bar' : 'area'}
            />
          </Card>
        ))}
      </div>
      <Card className="report-card">
        <span className="eyebrow">CONSISTENCY / NOT PERFECTION</span>
        <h2>{tracked} days of checking in.</h2>
        <p>
          {tracked} of the last {days} days include meal, water, sleep or movement entries.
        </p>
        <p>
          {sleeps.length
            ? `On the ${sleeps.length} days with sleep entries, you recorded an average of ${round(sleeps.reduce((n, p) => n + p.sleep, 0) / sleeps.length)} hours.`
            : 'Add sleep sessions to see your recorded rest over time.'}
        </p>
        <small>
          Missing logs do not describe your actual habits. These charts show only the records you
          saved.
        </small>
      </Card>
    </>
  );
}
