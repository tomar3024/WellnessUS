import { PHASE2 } from '../utils/phase';
import { useState } from 'react';
import { Check, Download, ShieldCheck } from 'lucide-react';
import { Card, Field, SectionTitle } from '../components/UI';
import { api, message } from '../services/api';
import { useAuth } from '../context/AuthContext';
export default function Settings({ data, reload }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(''),
    [saved, setSaved] = useState(false);
  const { user } = useAuth();
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setSaved(false);
    setError('');
    const values = Object.fromEntries(new FormData(e.currentTarget));
    values.weeklyWorkouts ??= data.goals.weeklyWorkouts || 3;
    for (const key of Object.keys(values))
      values[key] = values[key] === '' ? null : Number(values[key]);
    try {
      await api.put('/goals', values);
      await reload();
      setSaved(true);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  function exportData() {
    const blob = new Blob(
      [JSON.stringify({ exportedAt: new Date().toISOString(), account: user, ...data }, null, 2)],
      { type: 'application/json' },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'wellnessus-my-records.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return (
    <>
      <SectionTitle title="Set your own daily targets.">
        Personal references for your routines. You can change them any time.
      </SectionTitle>
      <div className="profile-layout">
        <Card>
          <h2>Wellness goals</h2>
          <p className="muted">
            These are customizable tracking references, not medical recommendations.
          </p>
          <form onSubmit={submit}>
            <div className="form-grid">
              {[
                ['water', 'Daily hydration (ml)', 250, 6000, 50],
                ['sleep', 'Nightly sleep (hours)', 4, 14, 0.25],
                ...(PHASE2 ? [['weeklyWorkouts', 'Weekly activity sessions', 0, 7, 1]] : []),
              ].map(([name, label, min, max, step]) => (
                <Field key={name} label={label}>
                  <input
                    name={name}
                    type="number"
                    min={min}
                    max={max}
                    step={step}
                    required
                    defaultValue={data.goals[name]}
                  />
                </Field>
              ))}
            </div>
            <h3>Daily calorie & protein references</h3>
            <p className="muted">
              Leave blank to track without targets. We never generate a calorie or weight-loss
              target from BMI.
            </p>
            <div className="form-grid">
              {[
                ['calories', 'Calories (kcal)', 10000],
                ['protein', 'Protein (g)', 500],
              ].map(([name, label, max]) => (
                <Field label={label} key={name}>
                  <input
                    name={name}
                    type="number"
                    min="1"
                    max={max}
                    step="1"
                    defaultValue={data.goals[name] ?? ''}
                    placeholder="No reference set"
                  />
                </Field>
              ))}
            </div>
            {saved && (
              <p className="success">
                <Check size={16} />
                Goals saved
              </p>
            )}
            {error && (
              <p className="error" role="alert">
                {error}
              </p>
            )}
            <button className="button" disabled={busy}>
              {busy ? 'Saving…' : 'Save goals'}
            </button>
          </form>
        </Card>
        <div>
          <Card>
            <ShieldCheck size={25} />
            <h2>Your account</h2>
            <strong>{user.name}</strong>
            <p className="muted">{user.email}</p>
            <p>
              Your records belong to your account. Tracking data is checked for ownership on the
              server.
            </p>
            <button className="button secondary" onClick={exportData}>
              <Download size={16} /> Export my data
            </button>
          </Card>
          <Card className="soft-card">
            <h3>Understanding calorie balance</h3>
            <p>
              Calorie balance describes the relationship between energy consumed and energy used. A
              deficit means intake is lower than expenditure; a surplus means intake is higher.
            </p>
            <p>
              These are educational concepts, not personal prescriptions. Needs vary with age,
              development, activity, and health. Under-18 users receive no adult BMI category or
              automated weight-loss prescription.
            </p>
          </Card>
        </div>
      </div>
    </>
  );
}
