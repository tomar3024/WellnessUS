import { Link } from 'react-router-dom';
import { ArrowUpRight, Compass, Ruler, Scale } from 'lucide-react';
import { Card, Empty, SectionTitle } from '../components/UI';
export function BmiSummary({ profile }) {
  const b = profile?.bmi;
  return (
    <Card className="bmi-card">
      <div className="card-heading">
        <span className="eyebrow">YOUR BODY MASS INDEX</span>
        <Compass size={20} />
      </div>
      {b ? (
        <>
          <div className="bmi-value">
            {b.value}
            <small>kg/m²</small>
          </div>
          <span className="category-badge">{b.category || 'Individual interpretation needed'}</span>
          {b.category && (
            <>
              <div className="bmi-scale" aria-hidden="true">
                <span />
                <span />
                <span />
                <span />
              </div>
              <div className="bmi-legend">
                <span>&lt;18.5</span>
                <span>18.5–24.9</span>
                <span>25–29.9</span>
                <span>30+</span>
              </div>
            </>
          )}
          <p>{b.information}</p>
          <div className="measurement-row">
            <span>
              <Ruler size={15} />
              {profile.height} cm
            </span>
            <span>
              <Scale size={15} />
              {profile.weight} kg
            </span>
            <span>{profile.age} years</span>
          </div>
        </>
      ) : (
        <Empty
          title="Start with your health quiz"
          action={
            <Link className="button secondary" to="/profile">
              Complete my profile
            </Link>
          }
        >
          Add your measurements to see your BMI and starting roadmap.
        </Empty>
      )}
    </Card>
  );
}
export default function Roadmap({ data }) {
  const roadmap = data.profile?.roadmap;
  return (
    <>
      <SectionTitle eyebrow="YOUR PERSONAL STARTING GUIDE" title="Find your next step.">
        A simple roadmap informed by your BMI and the context you shared.
      </SectionTitle>
      <div className="profile-layout">
        <div className="roadmap-list">
          {roadmap ? (
            roadmap.steps.map((step, i) => (
              <Card className="roadmap-step" key={step.title}>
                <span className="step-number">0{i + 1}</span>
                <div>
                  <h2>{step.title}</h2>
                  <p>{step.detail}</p>
                </div>
              </Card>
            ))
          ) : (
            <Card>
              <Empty
                title="Your roadmap starts with your profile"
                action={
                  <Link className="button" to="/profile">
                    Take the health quiz
                  </Link>
                }
              >
                Answer a few short questions first.
              </Empty>
            </Card>
          )}
          {roadmap && <p className="roadmap-note">{roadmap.information}</p>}
        </div>
        <div>
          <BmiSummary profile={data.profile} />
          {roadmap && (
            <Card>
              <h3>Read the reference guidance</h3>
              <div className="source-links">
                {roadmap.sources.map((s) => (
                  <a href={s.url} key={s.url} target="_blank" rel="noreferrer">
                    {s.title}
                    <ArrowUpRight size={15} />
                  </a>
                ))}
              </div>
              <p className="muted">
                Standard adult BMI thresholds are shown. Interpretation can differ by ethnicity and
                body composition. Children, teenagers and pregnancy need individual context.
              </p>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
