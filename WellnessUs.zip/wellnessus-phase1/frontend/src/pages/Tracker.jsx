import { sleepDaySummary } from '../utils/sleepLimits';
import { DailyMacros, MealGuidance, FoodBreakdown } from '../components/NutritionSummary';
import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Droplets,
  Moon,
  Dumbbell,
  Flame,
  Search,
  BookOpen,
  Clock3,
} from 'lucide-react';
import { Card, Empty, SectionTitle } from '../components/UI';
import { GoalRing, TrendChart, weekData, TrackingTrends } from '../components/Charts';
import { dateLabel, localDate, sum, round, entryTime } from '../utils/dates';
import { useClock } from '../hooks/useClock';
import { PHASE2 } from '../utils/phase';
const config = {
  meals: {
    title: 'Fuel your day.',
    description: 'Meals logged as they happen. Nutrition values are estimates.',
    name: 'meal',
    icon: Flame,
  },
  water: {
    title: 'Stay in your flow.',
    description: 'Every glass counts. Logged at the current date and time.',
    name: 'water entry',
    icon: Droplets,
  },
  sleep: {
    title: 'Rest is part of the plan.',
    description: 'Record your nights. Build a rhythm that works for you.',
    name: 'sleep session',
    icon: Moon,
  },
  workouts: {
    title: 'Move with intention.',
    description: 'Your movement, at your own pace.',
    name: 'workout',
    icon: Dumbbell,
  },
  journal: {
    title: 'Make space to reflect.',
    description: 'A private place to check in with yourself.',
    name: 'journal entry',
    icon: BookOpen,
  },
};
export default function Tracker({ module, data, open, remove, addWater, waterBusy, customFood }) {
  const clock = useClock();
  const [date, setDate] = useState(localDate()),
    [search, setSearch] = useState(''),
    [all, setAll] = useState(module === 'journal');
  useEffect(() => {
    setDate(clock.today);
  }, [clock.today]);
  const sleepFull = module === 'sleep' && data.sleep.filter((r) => r.date === date).length >= 2;
  const c = config[module],
    Icon = c.icon,
    automatic = ['meals', 'water'].includes(module);
  const rows = (data[module] || []).filter(
    (r) =>
      (all || r.date === date) &&
      (module !== 'journal' ||
        `${r.title} ${r.content}`.toLowerCase().includes(search.toLowerCase())),
  );
  const todayRows = data[module].filter((r) => r.date === clock.today),
    calories = todayRows.reduce((n, r) => n + (r.totals?.calories || 0), 0);
  const sleepSummary = module === 'sleep' ? sleepDaySummary(todayRows) : null;
  return (
    <>
      <SectionTitle
        eyebrow="YOUR DAILY TRACKER"
        title={c.title}
        action={
          <div className="heading-actions">
            {module === 'meals' && (
              <button className="button secondary" onClick={customFood}>
                Custom food
              </button>
            )}
            <button
              className="button"
              disabled={sleepFull}
              onClick={() => open(module, null, automatic ? undefined : date)}
            >
              <Plus size={17} />
              {sleepFull ? '2 sessions logged for this date' : `Log ${c.name}`}
            </button>
          </div>
        }
      >
        {c.description}
      </SectionTitle>
      {automatic && (
        <div className="tracking-clock">
          <span className="live-dot" />
          <Clock3 size={16} />
          <strong>
            {clock.now.toLocaleDateString(undefined, {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
            })}
          </strong>
          <span>{clock.now.toLocaleTimeString()}</span>
          <small>{clock.timeZone} · New entries always log now.</small>
        </div>
      )}
      {module === 'meals' && (
        <div className="tracker-overview">
          <Card>
            <div className="card-heading">
              <h2>Today’s calorie goal</h2>
              <Flame size={20} />
            </div>
            <GoalRing value={calories} goal={data.goals.calories} unit="kcal" label="Calories" />
          </Card>
          <Card className="macro-card">
            <DailyMacros meals={todayRows} plan={data.plan} />
          </Card>
        </div>
      )}
      {module === 'water' && (
        <div className="tracker-overview">
          <Card>
            <div className="card-heading">
              <h2>Today’s hydration</h2>
              <Droplets size={20} />
            </div>
            <GoalRing
              value={sum(todayRows, 'amount')}
              goal={data.goals.water}
              unit="ml"
              label="Water"
            />
            <div className="water-buttons">
              {[150, 250, 500].map((a) => (
                <button key={a} disabled={waterBusy} onClick={() => addWater(a)}>
                  <Plus size={14} />
                  {a} ml
                </button>
              ))}
            </div>
          </Card>
          <Card className="hydration-guide">
            <span className="eyebrow">MAKE IT A RHYTHM</span>
            <h2>
              One glass.
              <br />
              One small reset.
            </h2>
            <p>
              Use a quick-add button or log a custom amount. Every new entry uses the current time,
              even when you are browsing older history.
            </p>
            <p className="muted">
              Your daily reference is {data.goals.water.toLocaleString()} ml. Adjust it for your own
              needs in Settings.
            </p>
          </Card>
        </div>
      )}
      {module === 'sleep' && sleepSummary && !sleepSummary.valid && (
        <div className="error" role="alert">
          Older sleep entries exceed the new daily limits. Review and edit or delete the entries in
          your history; they have been preserved.
        </div>
      )}
      {module === 'sleep' && (
        <div className="tracker-overview">
          <Card className="sleep-summary">
            <div className="metric-title">
              <Moon size={21} />
              <h2>Rest recorded today</h2>
            </div>
            <div className="sleep-number">
              {todayRows.length && sleepSummary.valid ? round(sleepSummary.hours) : '—'}
              <small>hours</small>
            </div>
            <p>
              Your reference: {data.goals.sleep} hours. Up to two sessions and 24 hours per wake-up
              date. Sleep entries belong to the morning you wake up.
            </p>
          </Card>
          <Card>
            <span className="eyebrow">OVERNIGHT? HANDLED.</span>
            <h2>22:30 → 06:30 = 8 hours.</h2>
            <p className="muted">
              Enter your bedtime and wake-up time. We calculate the duration automatically,
              including sessions across midnight.
            </p>
          </Card>
        </div>
      )}
      {module === 'meals' && (
        <>
          <MealGuidance plan={data.plan} />
          <FoodBreakdown meals={todayRows} />
        </>
      )}
      {['meals', 'water', 'sleep'].includes(module) && (
        <TrackingTrends data={data} module={module} />
      )}
      {module === 'workouts' && <Planner profile={data.profile} />}
      <Card>
        <div className="card-heading wrap">
          <div>
            <h2>{module === 'journal' ? 'Your entries' : 'Your history'}</h2>
            <p>
              {rows.length} saved {rows.length === 1 ? 'entry' : 'entries'}
              {all ? '' : ` · ${dateLabel(date)}`}
            </p>
          </div>
          <div className="history-filters">
            <label className="checkbox">
              <input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} />
              All dates
            </label>
            <label className="sr-only" htmlFor="history-date">
              History date
            </label>
            <input
              id="history-date"
              type="date"
              value={date}
              onChange={(e) => {
                setDate(e.target.value || localDate());
                setAll(false);
              }}
            />
          </div>
        </div>
        {module === 'journal' && (
          <div className="search-input">
            <Search size={18} />
            <input
              aria-label="Search journal"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search your thoughts…"
            />
          </div>
        )}
        {rows.length ? (
          <div className={module === 'journal' ? 'journal-grid' : 'records-list'}>
            {rows.map((r) => (
              <article
                className={module === 'journal' ? 'journal-entry' : 'record-row'}
                key={r._id}
              >
                <span className="record-icon">
                  <Icon size={20} />
                </span>
                <div className="record-detail">
                  <small>
                    {dateLabel(r.date)}
                    {automatic
                      ? ` · ${entryTime(r)}`
                      : module === 'journal'
                        ? ` · Feeling ${r.mood.toLowerCase()}`
                        : ''}
                  </small>
                  <strong>
                    {module === 'meals'
                      ? r.type
                      : module === 'water'
                        ? `${r.amount} ml water`
                        : module === 'sleep'
                          ? `${r.hours} hours · ${r.bedtime} → ${r.wakeTime}`
                          : module === 'workouts'
                            ? `${r.type} · ${r.duration} min`
                            : r.title}
                  </strong>
                  {module === 'meals' && (
                    <>
                      <p>{r.items.map((i) => `${i.name} × ${i.quantity}`).join(' · ')}</p>
                      <small>
                        {round(r.totals.calories)} kcal · {round(r.totals.protein)} g protein
                      </small>
                    </>
                  )}
                  {module === 'workouts' && r.exercises?.length > 0 && (
                    <p>
                      {r.exercises.map((ex) => `${ex.name}: ${ex.sets} × ${ex.reps}`).join(' · ')}
                    </p>
                  )}
                  {r.notes && <p className="preserve-text">{r.notes}</p>}
                  {module === 'journal' && <p className="preserve-text">{r.content}</p>}
                </div>
                <div className="record-actions">
                  <button
                    className="icon-button"
                    aria-label={`Edit ${c.name}`}
                    onClick={() => open(module, r)}
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    className="icon-button danger"
                    aria-label={`Delete ${c.name}`}
                    onClick={() => remove(module, r)}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <Empty
            title={search ? 'No matching entries.' : 'A clean slate.'}
            action={
              <button
                className="button secondary"
                onClick={() => open(module, null, automatic ? undefined : date)}
              >
                <Plus size={15} />
                Log {c.name}
              </button>
            }
          >
            {search
              ? 'Try another search or choose all dates.'
              : automatic
                ? 'Log something now, or browse a different day in your history.'
                : 'Your saved entries will appear here.'}
          </Empty>
        )}
      </Card>
    </>
  );
}
function Planner({ profile }) {
  const [days, setDays] = useState(['Mon', 'Wed', 'Fri']),
    [type, setType] = useState(profile?.activityPreferences?.[0] || 'Walking'),
    [show, setShow] = useState(false);
  const templates = {
    Strength:
      'A comfortable full-body session: choose familiar movements, start light, and leave time to rest.',
    Walking: 'An easy walk at a conversational pace. Choose a duration that feels comfortable.',
    Running: 'An easy run or walk–run session, with a gentle warm-up and cool-down.',
    Cycling: 'A comfortable ride on a familiar route or stationary bike.',
    Yoga: 'A gentle mobility or yoga session with comfortable ranges of movement.',
    Swimming: 'An easy swim with breaks when needed.',
    Other: 'Choose an enjoyable activity at a comfortable intensity.',
  };
  return (
    <Card className="planner">
      <div className="card-heading">
        <div>
          <h2>A simple weekly planner</h2>
          <p>General activity ideas from predefined templates. Adapt to your ability.</p>
        </div>
      </div>
      <div className="planner-controls">
        <label>
          Activity
          <select
            value={type}
            onChange={(e) => {
              setType(e.target.value);
              setShow(false);
            }}
          >
            {Object.keys(templates).map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </label>
        <div className="day-selector" aria-label="Available days">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
            <button
              key={d}
              aria-pressed={days.includes(d)}
              className={days.includes(d) ? 'selected' : ''}
              onClick={() => {
                setDays(days.includes(d) ? days.filter((x) => x !== d) : [...days, d]);
                setShow(false);
              }}
            >
              {d}
            </button>
          ))}
        </div>
        <button className="button secondary" disabled={!days.length} onClick={() => setShow(true)}>
          Build my plan
        </button>
      </div>
      {show && (
        <div className="plan-result">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
            .filter((d) => days.includes(d))
            .map((day) => (
              <div key={day}>
                <strong>
                  {day} · {type}
                </strong>
                <p>{templates[type]}</p>
              </div>
            ))}
          <small>
            This planner is a reference, not a saved workout. Log completed sessions separately.
            Rest and adapt whenever needed.
          </small>
        </div>
      )}
    </Card>
  );
}
