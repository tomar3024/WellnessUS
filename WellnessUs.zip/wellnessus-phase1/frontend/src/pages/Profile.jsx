import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, ArrowLeft, Check, Sparkles, Info } from 'lucide-react';
import { Card, Field, SectionTitle, Brand } from '../components/UI';
import { api, message } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { timeZone } from '../utils/dates';
const initial = {
  age: '',
  sex: 'Prefer not to say',
  height: '',
  weight: '',
  pregnancyStatus: 'Not applicable',
  breastfeeding: false,
  eatingConcern: false,
  healthContext: '',
  unintentionalWeightChange: false,
  objective: 'Improve general health',
  nutritionIntent: 'Maintain my current routine',
  primaryGoal: '',
  secondaryGoal: 'None for now',
  energyPreference: 'Start around maintenance',
  activity: 'Lightly active',
  workPattern: 'Mixed',
  exerciseFrequency: 'Never',
  averageSleep: 8,
  mealConsistency: 'Getting started',
  hydrationConsistency: 'Getting started',
  activityPreferences: [],
  nutritionPreference: 'Balanced tracking',
  dietPreference: 'No preference',
  appetite: 'Usually comfortable',
  mealFrequency: 3,
};
export function ProfileForm({ profile, goals, onSaved, onboarding = false }) {
  const [step, setStep] = useState(0),
    [values, setValues] = useState({
      ...initial,
      ...Object.fromEntries(
        Object.keys(initial)
          .filter((k) => profile?.[k] !== undefined)
          .map((k) => [k, profile[k]]),
      ),
    }),
    [chosen, setChosen] = useState({
      calorieGoal: goals?.calories ?? '',
      proteinGoal: goals?.protein ?? '',
      waterGoal: goals?.water ?? 2000,
      sleepGoal: goals?.sleep ?? 8,
    }),
    [plan, setPlan] = useState(null),
    [explanation, setExplanation] = useState(null),
    [busy, setBusy] = useState(false),
    [aiBusy, setAiBusy] = useState(false),
    [error, setError] = useState(''),
    [goalTouched, setGoalTouched] = useState(false),
    [proteinTouched, setProteinTouched] = useState(false);
  const raw = Number(values.weight) / (Number(values.height) / 100) ** 2,
    adult = Number(values.age) >= 18,
    under = adult && raw < 18.5,
    above = adult && raw >= 25;
  function change(name, value) {
    setValues((v) => ({
      ...v,
      [name]: value,
      ...(name === 'sex' && value === 'Male'
        ? { pregnancyStatus: 'Not applicable', breastfeeding: false }
        : {}),
    }));
    setExplanation(null);
  }
  const number = (name, label, min, max, increment = 1) => (
    <Field label={label}>
      <input
        type="number"
        required
        min={min}
        max={max}
        step={increment}
        value={values[name]}
        onChange={(e) => change(name, e.target.value)}
      />
    </Field>
  );
  const select = (name, label, options) => (
    <Field label={label}>
      <select value={values[name]} onChange={(e) => change(name, e.target.value)}>
        {options.map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    </Field>
  );
  const checkbox = (name, label) => (
    <label className="checkbox quiz-check">
      <input
        type="checkbox"
        checked={values[name]}
        onChange={(e) => change(name, e.target.checked)}
      />
      {label}
    </label>
  );
  function payload() {
    const p = { ...values, timeZone: timeZone() };
    for (const k of ['age', 'height', 'weight', 'averageSleep', 'mealFrequency'])
      p[k] = Number(p[k]);
    return p;
  }
  async function submit(e) {
    e.preventDefault();
    setError('');
    if (step < 2) {
      setStep(step + 1);
      return;
    }
    setBusy(true);
    try {
      if (step === 2) {
        const result = (await api.post('/nutrition-plan/preview', payload())).data.data;
        setPlan(result);
        if (!goalTouched)
          setChosen((v) => ({ ...v, calorieGoal: result.suggestedGoals?.calories ?? '' }));
        if (!proteinTouched)
          setChosen((v) => ({ ...v, proteinGoal: result.suggestedGoals?.protein ?? '' }));
        setStep(3);
      } else {
        await api.put('/profile', {
          ...payload(),
          applyGoals: true,
          calorieGoal: chosen.calorieGoal === '' ? null : Number(chosen.calorieGoal),
          proteinGoal: chosen.proteinGoal === '' ? null : Number(chosen.proteinGoal),
          waterGoal: Number(chosen.waterGoal),
          sleepGoal: Number(chosen.sleepGoal),
        });
        await onSaved();
      }
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  async function explain() {
    setAiBusy(true);
    setError('');
    try {
      setExplanation(
        (await api.post('/nutrition-plan/explain', { consent: true, profile: payload() })).data
          .data,
      );
    } catch (e) {
      setError(message(e));
    } finally {
      setAiBusy(false);
    }
  }
  const contextual = !adult || values.pregnancyStatus === 'Pregnant' || values.breastfeeding;
  const primaryOptions = contextual
    ? ['Support everyday wellbeing', 'Improve meal consistency', 'Build healthy routines']
    : under
      ? ['Gain weight', 'Gain weight and build muscle', 'Improve meal consistency']
      : above
        ? [
            'Build strength',
            'Improve fitness',
            'Discuss gradual fat loss',
            'Maintain current habits',
            'Build muscle',
          ]
        : [
            'Build muscle',
            'Build strength',
            'Gain a little weight',
            'Maintain current habits',
            'Improve meal consistency',
          ];
  const secondaryOptions = (
    contextual
      ? ['None for now', 'Improve meal consistency', 'Improve sleep consistency']
      : under
        ? [
            'None for now',
            'Build muscle',
            'Build strength',
            'Improve meal consistency',
            'Improve appetite routine',
          ]
        : [
            'None for now',
            'Build muscle',
            'Build strength',
            'Gain a little weight',
            'Improve fitness',
            'Improve meal consistency',
            'Improve sleep consistency',
          ]
  ).filter(
    (goal) =>
      goal !== values.primaryGoal &&
      !(above && goal === 'Gain a little weight') &&
      !(values.primaryGoal === 'Gain weight and build muscle' && goal === 'Build muscle') &&
      !(values.primaryGoal === 'Discuss gradual fat loss' && goal === 'Gain a little weight'),
  );
  useEffect(() => {
    setValues((v) => ({
      ...v,
      primaryGoal: primaryOptions.includes(v.primaryGoal) ? v.primaryGoal : '',
      secondaryGoal: secondaryOptions.includes(v.secondaryGoal) ? v.secondaryGoal : 'None for now',
      ...(v.sex === 'Male' ? { pregnancyStatus: 'Not applicable', breastfeeding: false } : {}),
    }));
  }, [adult, under, above, contextual, values.primaryGoal, values.sex]);
  return (
    <form className="profile-form" onSubmit={submit}>
      <div className="quiz-steps">
        {['About you', 'Your context', 'Your routine', 'Your goals'].map((label, i) => (
          <button
            key={label}
            type="button"
            disabled={i > step}
            className={step === i ? 'current' : i < step ? 'complete' : ''}
            onClick={() => setStep(i)}
          >
            <span>{i < step ? <Check size={12} /> : i + 1}</span>
            {label}
          </button>
        ))}
      </div>
      <fieldset hidden={step !== 0} disabled={step !== 0}>
        <h2>A few details to start.</h2>
        <p className="muted">
          Your answers shape the next questions and your estimated energy needs.
        </p>
        <div className="form-grid">
          {number('age', 'Age (years)', 5, 120)}
          {select('sex', 'Sex used by the energy equation (optional)', [
            'Female',
            'Male',
            'Intersex',
            'Prefer not to say',
          ])}
          {number('height', 'Height (cm)', 50, 250, 0.1)}
          {number('weight', 'Current weight (kg)', 10, 500, 0.1)}
        </div>
      </fieldset>
      <fieldset hidden={step !== 1} disabled={step !== 1}>
        <h2>
          {!adult
            ? 'Let’s support your growth.'
            : under
              ? 'Let’s understand your nourishment.'
              : above
                ? 'What would you like to work on?'
                : 'What would feeling well look like?'}
        </h2>
        {adult && values.pregnancyStatus !== 'Pregnant' && Number.isFinite(raw) && (
          <p className="quiz-context">
            Your BMI is {raw.toFixed(1)} ·{' '}
            {under
              ? 'Underweight'
              : raw < 25
                ? 'Healthy BMI range'
                : raw < 30
                  ? 'Overweight'
                  : 'Obesity'}
            . BMI is one screening measure; it does not determine overall health.
          </p>
        )}
        <Field label="What is your primary goal?">
          <select
            required
            value={values.primaryGoal}
            onChange={(e) => change('primaryGoal', e.target.value)}
          >
            <option value="">Choose your main focus…</option>
            {primaryOptions.map((goal) => (
              <option key={goal}>{goal}</option>
            ))}
          </select>
        </Field>
        {select('secondaryGoal', 'And a secondary goal? (optional)', secondaryOptions)}
        {under && values.primaryGoal && (
          <p className="quiz-context">
            You can work toward gaining weight and building muscle together. Choose which matters
            most, then add a supporting goal.
          </p>
        )}
        {!contextual &&
          !under &&
          !above &&
          ![values.primaryGoal, values.secondaryGoal].some((goal) =>
            ['Gain weight', 'Gain weight and build muscle', 'Gain a little weight'].includes(goal),
          ) &&
          [values.primaryGoal, values.secondaryGoal].some((goal) =>
            /muscle|strength/i.test(goal),
          ) &&
          select('energyPreference', 'How would you like to approach muscle or strength gains?', [
            'Start around maintenance',
            'Consider a small surplus',
          ])}
        {under && (
          <>
            {select('appetite', 'How has your appetite been?', [
              'Usually comfortable',
              'Often low',
              'Often very hungry',
              'Variable',
            ])}
            {number('mealFrequency', 'How many meals or snacks do you usually eat?', 1, 8)}
          </>
        )}
        {checkbox('unintentionalWeightChange', 'I have noticed an unexplained change in weight.')}
        {checkbox(
          'eatingConcern',
          'Calorie or weight tracking may be difficult for my relationship with food.',
        )}
        {values.sex !== 'Male' && (
          <div className="form-grid">
            {select('pregnancyStatus', 'Pregnancy context (optional)', [
              'Not applicable',
              'Not pregnant',
              'Pregnant',
              'Prefer not to say',
            ])}
            {checkbox('breastfeeding', 'I am breastfeeding.')}
          </div>
        )}
        <Field label="Any health or dietary considerations? (optional)">
          <textarea
            rows="2"
            maxLength={500}
            value={values.healthContext}
            onChange={(e) => change('healthContext', e.target.value)}
            placeholder="Only share what you want recorded."
          />
        </Field>
      </fieldset>
      <fieldset hidden={step !== 2} disabled={step !== 2}>
        <h2>Build around your actual day.</h2>
        <p className="muted">
          Activity changes your estimated maintenance needs. Choose what best describes your usual
          week.
        </p>
        <div className="form-grid">
          {select('activity', 'Usual activity level', [
            'Mostly sedentary',
            'Lightly active',
            'Moderately active',
            'Very active',
          ])}
          {select(
            'workPattern',
            values.activity === 'Mostly sedentary'
              ? 'How much of your day is seated?'
              : 'What does your workday involve?',
            ['Mostly sitting', 'On my feet', 'Physically demanding', 'Mixed'],
          )}
          {select('exerciseFrequency', 'Movement during a usual week', [
            'Never',
            '1–2 days',
            '3–4 days',
            '5 or more days',
          ])}
          {number('averageSleep', 'Average sleep (hours)', 1, 23, 0.25)}
          {select('dietPreference', 'Food preference', [
            'No preference',
            'Vegetarian',
            'Vegan',
            'Eggs and dairy',
            'Other',
          ])}
          {select('nutritionPreference', 'Nutrition focus', [
            'Balanced tracking',
            'Protein awareness',
            'Meal consistency',
          ])}
          {select('mealConsistency', 'How regular are your meals?', [
            'Getting started',
            'Sometimes consistent',
            'Usually consistent',
          ])}
          {select('hydrationConsistency', 'How regular is your water intake?', [
            'Getting started',
            'Sometimes consistent',
            'Usually consistent',
          ])}
        </div>
        {values.mealConsistency !== 'Usually consistent' && (
          <p className="quiz-context">
            Start by noticing your meal routine. Your goal can focus on consistency rather than
            changing weight.
          </p>
        )}
        {Number(values.averageSleep) < 7 && adult && (
          <p className="quiz-context">
            You reported a shorter sleep routine. On the next step, choose a realistic sleep
            reference to track.
          </p>
        )}
      </fieldset>
      <fieldset hidden={step !== 3} disabled={step !== 3}>
        <h2>Your estimate. Your decision.</h2>
        {plan?.estimate ? (
          <div className="estimate-box">
            <span className="eyebrow">ESTIMATED DAILY MAINTENANCE</span>
            <strong>
              {plan.estimate.low.toLocaleString()}–{plan.estimate.high.toLocaleString()}
              <small>kcal / day</small>
            </strong>
            <p>
              Approximate center: {plan.estimate.maintenance.toLocaleString()} kcal. Based on your
              measurements, equation sex and activity. This is an estimate, not a measured
              requirement.
            </p>
            <a href={plan.estimate.source} target="_blank" rel="noreferrer" className="text-button">
              How the equation works <ArrowRight size={13} />
            </a>
          </div>
        ) : (
          <div className="quiz-context">
            An automatic estimate is not suitable for these answers. You can track meals without a
            calorie budget and seek individualized guidance.
          </div>
        )}
        <p className="plan-explanation">{plan?.explanation}</p>
        {plan?.suggestedGoals && (
          <div className="goal-suggestion">
            <h3>Your two-goal starting references</h3>
            <p>{plan.suggestedGoals.reason}</p>
            {plan.suggestedGoals.protein && (
              <p>
                {plan.suggestedGoals.proteinReason}{' '}
                <a href={plan.suggestedGoals.source} target="_blank" rel="noreferrer">
                  Protein reference
                </a>
              </p>
            )}
          </div>
        )}
        {plan?.estimate && (
          <div className="ai-explanation">
            <button className="button secondary" type="button" onClick={explain} disabled={aiBusy}>
              <Sparkles size={15} />
              {aiBusy ? 'Requesting explanation…' : 'Explain this with Gemini'}
            </button>
            <small>
              Shares only the derived estimate and goal direction with Google. No name, email or
              health notes.
            </small>
            {explanation && (
              <p>
                {explanation.summary}
                <small>
                  {explanation.available
                    ? 'Gemini explanation'
                    : 'Calculation-based fallback · ' + explanation.reason}
                </small>
              </p>
            )}
          </div>
        )}
        <div className="form-grid">
          <Field
            label="Choose your calorie reference (kcal/day)"
            hint="This reflects the goals you selected. Review it, change it, or leave blank to track without a budget."
          >
            <input
              type="number"
              min="1"
              max="10000"
              value={chosen.calorieGoal}
              onChange={(e) => {
                setGoalTouched(true);
                setChosen((v) => ({ ...v, calorieGoal: e.target.value }));
              }}
              placeholder="No calorie budget"
            />
          </Field>
          <Field
            label="Choose your protein reference (g/day)"
            hint="Suggested from body weight and your muscle, strength or weight-gain focus. You can change it or leave it blank."
          >
            <input
              type="number"
              min="1"
              max="500"
              value={chosen.proteinGoal}
              onChange={(e) => {
                setProteinTouched(true);
                setChosen((v) => ({ ...v, proteinGoal: e.target.value }));
              }}
              placeholder="No protein reference"
            />
          </Field>
          <Field label="Water reference (ml/day)">
            <input
              type="number"
              min="250"
              max="6000"
              step="50"
              required
              value={chosen.waterGoal}
              onChange={(e) => setChosen((v) => ({ ...v, waterGoal: e.target.value }))}
            />
          </Field>
          <Field label="Sleep reference (hours)">
            <input
              type="number"
              min="4"
              max="14"
              step=".25"
              required
              value={chosen.sleepGoal}
              onChange={(e) => setChosen((v) => ({ ...v, sleepGoal: e.target.value }))}
            />
          </Field>
        </div>
        <p className="muted">
          Saving confirms the calorie and protein references you reviewed. Suggestions remain
          editable and are not applied before you confirm.
        </p>
      </fieldset>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <div className="form-actions">
        {step > 0 && (
          <button className="button secondary" type="button" onClick={() => setStep(step - 1)}>
            <ArrowLeft size={15} />
            Back
          </button>
        )}
        <button className="button" disabled={busy}>
          {busy ? 'Saving…' : step < 3 ? 'Continue' : 'Save profile & chosen goals'}
          <ArrowRight size={16} />
        </button>
      </div>
    </form>
  );
}
export default function Profile({ data, reload }) {
  const [saved, setSaved] = useState(false);
  return (
    <>
      <SectionTitle eyebrow="PERSONAL DETAILS" title="Make it personal.">
        Update your answers and choose goals that fit your routine.
      </SectionTitle>
      <div className="profile-layout">
        <Card>
          <ProfileForm
            profile={data.profile}
            goals={data.goals}
            onSaved={async () => {
              await reload();
              setSaved(true);
            }}
          />
          {saved && (
            <p className="success">
              <Check size={16} />
              Profile and chosen goals saved.
            </p>
          )}
        </Card>
        <Card className="bmi-card">
          <span className="eyebrow">YOUR BASELINE</span>
          <div className="bmi-value">
            {data.profile?.bmi.value ?? '—'}
            <small>kg/m²</small>
          </div>
          <span className="category-badge">
            {data.profile?.bmi.category || 'Individual interpretation needed'}
          </span>
          <p>{data.profile?.bmi.information || 'Complete your profile to calculate BMI.'}</p>
          <p className="muted">
            Maintenance and nutrient references appear in Meals & calories after your quiz.
          </p>
        </Card>
      </div>
    </>
  );
}
export function Onboarding() {
  const { refresh } = useAuth(),
    navigate = useNavigate();
  return (
    <main className="onboarding">
      <Brand />
      <Card>
        <SectionTitle eyebrow="YOUR PERSONAL STARTING POINT" title="Let’s find your rhythm.">
          A short conversation about you, your routine and the goals you choose.
        </SectionTitle>
        <ProfileForm
          onboarding
          onSaved={async () => {
            await refresh();
            navigate('/');
          }}
        />
      </Card>
    </main>
  );
}
