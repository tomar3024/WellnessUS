import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
dotenv.config({ path: fileURLToPath(new URL('../../.env', import.meta.url)) });
export function config() {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret.length < 32 || secret.startsWith('replace-'))
    throw new Error('Set JWT_SECRET to a random value of at least 32 characters in backend/.env');
  if (!process.env.MONGODB_URI) throw new Error('Set MONGODB_URI in backend/.env');
  return {
    geminiKey: process.env.GEMINI_API_KEY || '',
    geminiModel: process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite',
    usdaKey: process.env.USDA_API_KEY || '',
    projectPhase: Number(process.env.PROJECT_PHASE || 1),
    secret,
    mongo: process.env.MONGODB_URI,
    port: Number(process.env.PORT || 4000),
    origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
    production: process.env.NODE_ENV === 'production',
  };
}
