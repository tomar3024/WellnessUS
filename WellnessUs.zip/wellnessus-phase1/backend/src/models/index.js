import mongoose from 'mongoose';
const { Schema } = mongoose;
const owner = { type: Schema.Types.ObjectId, ref: 'User', required: true };
const date = { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ };
function model(name, fields, unique = false) {
  const schema = new Schema({ user: owner, ...fields }, { timestamps: true, strict: 'throw' });
  if (unique) schema.index({ user: 1 }, { unique: true });
  else schema.index({ user: 1, date: -1 });
  return mongoose.model(name, schema);
}
export const User = mongoose.model(
  'User',
  new Schema(
    {
      name: { type: String, required: true, maxlength: 80 },
      email: { type: String, required: true, unique: true, lowercase: true },
      passwordHash: { type: String, required: true, select: false },
      sessionVersion: { type: Number, default: 0 },
      onboarded: { type: Boolean, default: false },
    },
    { timestamps: true },
  ),
);
export const LifestyleProfile = model(
  'LifestyleProfile',
  {
    age: Number,
    breastfeeding: Boolean,
    eatingConcern: Boolean,
    nutritionIntent: String,
    primaryGoal: String,
    secondaryGoal: String,
    energyPreference: String,
    dietPreference: String,
    workPattern: String,
    appetite: String,
    mealFrequency: Number,
    sex: String,
    pregnancyStatus: String,
    healthContext: String,
    unintentionalWeightChange: Boolean,
    timeZone: String,
    height: Number,
    weight: Number,
    objective: String,
    activity: String,
    exerciseFrequency: String,
    averageSleep: Number,
    mealConsistency: String,
    hydrationConsistency: String,
    activityPreferences: [String],
    nutritionPreference: String,
  },
  true,
);
export const WellnessGoal = model(
  'WellnessGoal',
  {
    water: { type: Number, default: 2000 },
    sleep: { type: Number, default: 8 },
    weeklyWorkouts: { type: Number, default: 3 },
    calories: { type: Number, default: null },
    protein: { type: Number, default: null },
  },
  true,
);
export const Food = mongoose.model(
  'Food',
  new Schema(
    {
      user: { ...owner, required: false, default: null },
      name: { type: String, required: true },
      serving: { type: String, required: true },
      calories: { type: Number, min: 0, required: true },
      protein: { type: Number, min: 0, required: true },
      carbs: { type: Number, min: 0, required: true },
      fat: { type: Number, min: 0, required: true },
      fiber: { type: Number, min: 0, default: null },
      estimated: { type: Boolean, default: true },
    },
    { timestamps: true },
  ),
);
const foodItem = new Schema(
  {
    name: String,
    serving: String,
    quantity: Number,
    calories: Number,
    protein: Number,
    carbs: Number,
    fat: Number,
    fiber: { type: Number, default: null },
  },
  { _id: false },
);
export const Meal = model('Meal', {
  date,
  recordedAt: Date,
  timeZone: String,
  type: String,
  items: [foodItem],
  totals: {
    calories: Number,
    protein: Number,
    carbs: Number,
    fat: Number,
    fiber: Number,
    fiberComplete: Boolean,
  },
});
export const WaterLog = model('WaterLog', {
  date,
  recordedAt: Date,
  timeZone: String,
  amount: { type: Number, min: 1, max: 5000 },
});
export const SleepLog = model('SleepLog', {
  date,
  bedtime: String,
  wakeTime: String,
  hours: Number,
  notes: String,
});
export const Workout = model('Workout', {
  date,
  type: String,
  duration: Number,
  exercises: [new Schema({ name: String, sets: Number, reps: Number }, { _id: false })],
  notes: String,
});
export const WeightLog = model('WeightLog', { date, weight: { type: Number, min: 10, max: 500 } });
export const JournalEntry = model('JournalEntry', {
  date,
  title: String,
  content: String,
  mood: String,
});
export const records = {
  meals: Meal,
  water: WaterLog,
  sleep: SleepLog,
  workouts: Workout,
  weight: WeightLog,
  journal: JournalEntry,
};
