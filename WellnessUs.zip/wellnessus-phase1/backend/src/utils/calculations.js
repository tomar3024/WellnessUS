export function bmi(weight, height, age, context = {}) {
  const raw = weight / (height / 100) ** 2;
  const value = Math.round(raw * 10) / 10;
  if (context.pregnancyStatus === 'Pregnant')
    return {
      value,
      code: 'pregnancy',
      category: null,
      information:
        'Standard BMI categories are not used during pregnancy. Discuss your measurements and nutrition needs with your maternity care team.',
    };
  if (age < 18)
    return {
      value,
      code: 'under18',
      category: null,
      information:
        'For people under 18, BMI needs age- and sex-specific interpretation by a qualified health professional. Adult categories do not apply.',
    };
  const category =
    raw < 18.5
      ? 'Underweight'
      : raw < 25
        ? 'Healthy BMI range'
        : raw < 30
          ? 'Overweight'
          : 'Obesity';
  return {
    value,
    code: raw < 18.5 ? 'underweight' : raw < 25 ? 'healthy' : raw < 30 ? 'overweight' : 'obesity',
    category,
    information:
      'BMI is a screening measure, not a diagnosis. It does not measure body composition or overall health. No weight target is generated.',
  };
}
export function roadmap(profile) {
  const result = bmi(profile.weight, profile.height, profile.age, profile);
  const paths = {
    underweight: [
      'Build a regular nourishment routine',
      'Try regular balanced meals and, if comfortable, nourishing snacks. Include a mix of protein foods, whole grains, fruit or vegetables, and fats.',
    ],
    healthy: [
      'Keep the habits that support you',
      'Maintain regular balanced meals and enjoyable activity. A healthy BMI range is one screening result, not proof of overall health.',
    ],
    overweight: [
      'Start with sustainable habits',
      'Notice meal patterns, include a variety of foods, and choose comfortable movement. Discuss weight-related goals with a qualified professional before changing your intake.',
    ],
    obesity: [
      'Make a supported, personal plan',
      'A clinician can review BMI alongside your medical history and other indicators. Focus on consistent meals, comfortable activity, and rest while you seek individual guidance.',
    ],
    under18: [
      'Support growth and everyday routines',
      'Adult BMI categories do not apply. A qualified professional can interpret BMI for age and sex. Focus on regular meals, hydration, rest, and enjoyable movement rather than weight-loss targets.',
    ],
    pregnancy: [
      'Use pregnancy-specific guidance',
      'Standard BMI categories are not used here. Your maternity care team can help with nutrition, hydration, and changes in weight during pregnancy.',
    ],
  };
  const [title, detail] = paths[result.code];
  const steps = [
    { title, detail },
    {
      title: 'Get to know your baseline',
      detail:
        'Log meals and water as they happen for a week. Notice your routine without treating every number as a score.',
    },
    {
      title: 'Make rest a consistent habit',
      detail: `You reported ${profile.averageSleep} hours of sleep. Use the sleep log to notice your bedtime rhythm and choose a routine that fits your age and needs.`,
    },
    {
      title: 'Review with the right support',
      detail:
        profile.healthContext || profile.unintentionalWeightChange
          ? 'You shared a health consideration or an unexplained weight change. Arrange a healthcare review before making weight-related changes. This app does not assess or diagnose that concern.'
          : 'Review your habits after a week. Speak with a qualified professional if you want individualized nutrition or weight-related advice.',
    },
  ];
  return {
    bmi: result,
    steps,
    information:
      'General education based on standard adult BMI ranges. No automatic calorie deficit, surplus, or weight-loss target is prescribed. BMI has limits; body composition, ethnicity, age and health context matter.',
    sources: [
      {
        title: 'NHS: BMI calculators and age guidance',
        url: 'https://www.nhs.uk/health-assessment-tools/calculate-your-body-mass-index/',
      },
      {
        title: 'NHS: healthy ways to gain weight',
        url: 'https://www.nhs.uk/live-well/healthy-weight/managing-your-weight/healthy-ways-to-gain-weight/',
      },
      {
        title: 'NHS: adult BMI and its limitations',
        url: 'https://www.nhs.uk/conditions/overweight-and-obesity/',
      },
    ],
  };
}
export function nutrition(items) {
  return items.reduce(
    (total, item) => {
      for (const key of ['calories', 'protein', 'carbs', 'fat', 'fiber'])
        total[key] = Math.round((total[key] + (item[key] || 0) * item.quantity) * 100) / 100;
      total.fiberComplete = total.fiberComplete && Number.isFinite(item.fiber);
      return total;
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, fiberComplete: true },
  );
}
export function sleepHours(bedtime, wakeTime) {
  const minutes = (value) => {
    const [h, m] = value.split(':').map(Number);
    return h * 60 + m;
  };
  return Math.round((((minutes(wakeTime) - minutes(bedtime) + 1440) % 1440) / 60) * 100) / 100;
}
