export function durationMinutes(bedtime, wakeTime) {
  const minutes = (value) => {
    const [h, m] = value.split(':').map(Number);
    return h * 60 + m;
  };
  return (minutes(wakeTime) - minutes(bedtime) + 1440) % 1440;
}
export function assertSleepDay(entries, incoming, excludedId = null) {
  const others = entries.filter(
    (entry) => entry.date === incoming.date && String(entry._id) !== String(excludedId),
  );
  const fail = (message) => {
    const error = new Error(message);
    error.code = 'SLEEP_LIMIT';
    throw error;
  };
  if (others.length >= 2)
    fail(
      'You can save at most two sleep sessions on the same wake-up date. Edit or delete an existing entry first.',
    );
  const total =
    others.reduce((minutes, entry) => minutes + durationMinutes(entry.bedtime, entry.wakeTime), 0) +
    durationMinutes(incoming.bedtime, incoming.wakeTime);
  if (total > 1440) fail('Sleep sessions on one wake-up date cannot total more than 24 hours.');
  return total;
}
export function sleepDaySummary(entries) {
  const minutes = entries.reduce(
    (total, entry) => total + durationMinutes(entry.bedtime, entry.wakeTime),
    0,
  );
  return {
    count: entries.length,
    minutes,
    hours: minutes / 60,
    valid: entries.length <= 2 && minutes <= 1440,
  };
}
// The documented local app uses one Express process. Serialize writes per user,
// including edits between dates, to prevent simultaneous requests using stale totals.
const queues = new Map();
export async function withSleepWrite(userId, action) {
  const key = String(userId),
    previous = queues.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => {
    release = resolve;
  });
  queues.set(key, current);
  await previous;
  try {
    return await action();
  } finally {
    release();
    if (queues.get(key) === current) queues.delete(key);
  }
}
