import { z } from 'zod';
import { validTimeZone } from './time.js';
const timeZone = z
  .string()
  .max(100)
  .refine(validTimeZone, 'Use a valid IANA time zone')
  .default('UTC');
const number = (min, max) => z.number().finite().min(min).max(max);
export const date = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine(
    (s) => !Number.isNaN(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s,
    'Use a valid calendar date',
  );
const text = (max = 200) => z.string().trim().min(1).max(max);
const notes = z.string().trim().max(3000).default('');
export const registerSchema = z
  .object({
    name: text(80),
    email: z
      .string()
      .trim()
      .email()
      .max(254)
      .transform((s) => s.toLowerCase()),
    password: z
      .string()
      .min(10)
      .max(72)
      .refine((s) => Buffer.byteLength(s, 'utf8') <= 72, 'Password must be at most 72 UTF-8 bytes'),
  })
  .strict();
export const loginSchema = registerSchema.omit({ name: true });
export const foodSchema = z
  .object({
    name: text(100),
    serving: text(80),
    calories: number(0, 10000),
    protein: number(0, 1000),
    carbs: number(0, 1000),
    fat: number(0, 1000),
    fiber: number(0, 1000).nullable().default(null),
  })
  .strict();
export const schemas = {
  meals: z
    .object({
      date: date.optional(),
      timeZone,
      type: z.enum(['Breakfast', 'Lunch', 'Dinner', 'Snacks']),
      items: z
        .array(foodSchema.extend({ quantity: number(0.01, 100) }))
        .min(1)
        .max(50),
    })
    .strict(),
  water: z.object({ date: date.optional(), timeZone, amount: number(1, 5000) }).strict(),
  sleep: z
    .object({
      date,
      bedtime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
      wakeTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
      notes,
    })
    .strict()
    .refine((v) => v.bedtime !== v.wakeTime, 'Bedtime and wake time must differ'),
  workouts: z
    .object({
      date,
      type: z.enum(['Strength', 'Walking', 'Running', 'Cycling', 'Yoga', 'Swimming', 'Other']),
      duration: number(1, 600),
      exercises: z
        .array(
          z
            .object({ name: text(100), sets: number(1, 100).int(), reps: number(1, 1000).int() })
            .strict(),
        )
        .max(30)
        .default([]),
      notes,
    })
    .strict(),
  weight: z.object({ date, weight: number(10, 500) }).strict(),
  journal: z
    .object({
      date,
      title: text(150),
      content: text(20000),
      mood: z.enum(['Great', 'Good', 'Okay', 'Low', 'Difficult']).default('Okay'),
    })
    .strict(),
};
export const profileSchema = z
  .object({
    age: number(5, 120).int(),
    sex: z.enum(['Female', 'Male', 'Intersex', 'Prefer not to say']).default('Prefer not to say'),
    breastfeeding: z.boolean().default(false),
    eatingConcern: z.boolean().default(false),
    nutritionIntent: z
      .enum([
        'Maintain my current routine',
        'Gradually gain weight',
        'Discuss gradual weight loss',
        'Improve meal consistency',
        'Support strength',
      ])
      .default('Maintain my current routine'),
    dietPreference: z
      .enum(['No preference', 'Vegetarian', 'Vegan', 'Eggs and dairy', 'Other'])
      .default('No preference'),
    workPattern: z
      .enum(['Mostly sitting', 'On my feet', 'Physically demanding', 'Mixed'])
      .default('Mixed'),
    appetite: z
      .enum(['Usually comfortable', 'Often low', 'Often very hungry', 'Variable'])
      .default('Usually comfortable'),
    mealFrequency: number(1, 8).int().default(3),
    applyGoals: z.boolean().optional(),
    primaryGoal: z
      .enum([
        '',
        'Build muscle',
        'Build strength',
        'Gain a little weight',
        'Gain weight',
        'Gain weight and build muscle',
        'Maintain current habits',
        'Improve meal consistency',
        'Improve fitness',
        'Discuss gradual fat loss',
        'Support everyday wellbeing',
        'Build healthy routines',
      ])
      .default(''),
    secondaryGoal: z
      .enum([
        'None for now',
        'Build muscle',
        'Build strength',
        'Gain a little weight',
        'Improve meal consistency',
        'Improve sleep consistency',
        'Improve appetite routine',
        'Improve fitness',
      ])
      .default('None for now'),
    energyPreference: z
      .enum(['Start around maintenance', 'Consider a small surplus'])
      .default('Start around maintenance'),
    proteinGoal: number(1, 500).nullable().optional(),
    calorieGoal: number(1, 10000).nullable().optional(),
    waterGoal: number(250, 6000).optional(),
    sleepGoal: number(4, 14).optional(),
    pregnancyStatus: z
      .enum(['Not applicable', 'Not pregnant', 'Pregnant', 'Prefer not to say'])
      .default('Not applicable'),
    healthContext: z.string().trim().max(500).default(''),
    unintentionalWeightChange: z.boolean().default(false),
    timeZone,
    height: number(50, 250),
    weight: number(10, 500),
    objective: z.enum([
      'Improve general health',
      'Build strength',
      'Improve physical fitness',
      'Maintain current habits',
      'Discuss weight-related goals',
    ]),
    activity: z.enum(['Mostly sedentary', 'Lightly active', 'Moderately active', 'Very active']),
    exerciseFrequency: z.enum(['Never', '1–2 days', '3–4 days', '5 or more days']),
    averageSleep: number(1, 23),
    mealConsistency: z.enum(['Getting started', 'Sometimes consistent', 'Usually consistent']),
    hydrationConsistency: z.enum(['Getting started', 'Sometimes consistent', 'Usually consistent']),
    activityPreferences: z
      .array(z.enum(['Strength', 'Walking', 'Running', 'Cycling', 'Yoga', 'Swimming', 'Other']))
      .max(7)
      .default([]),
    nutritionPreference: z
      .enum(['Balanced tracking', 'Protein awareness', 'Meal consistency'])
      .default('Balanced tracking'),
  })
  .strict()
  .superRefine((data, ctx) => {
    if (data.primaryGoal && data.primaryGoal === data.secondaryGoal)
      ctx.addIssue({
        code: 'custom',
        path: ['secondaryGoal'],
        message: 'Choose a different supporting goal, or None for now.',
      });
    if (
      data.primaryGoal === 'Discuss gradual fat loss' &&
      data.secondaryGoal === 'Gain a little weight'
    )
      ctx.addIssue({
        code: 'custom',
        path: ['secondaryGoal'],
        message: 'Choose a supporting goal that does not conflict with the primary goal.',
      });
  });
export const goalSchema = z
  .object({
    water: number(250, 6000),
    sleep: number(4, 14),
    weeklyWorkouts: number(0, 7).int(),
    calories: number(1, 10000).nullable().default(null),
    protein: number(1, 500).nullable().default(null),
  })
  .strict();
export function parse(schema, value) {
  return schema.parse(value);
}
