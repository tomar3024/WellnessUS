import { Router } from 'express';
import bcrypt from 'bcrypt';
import { rateLimit } from 'express-rate-limit';
import { User, LifestyleProfile, WellnessGoal, Food } from '../models/index.js';
import {
  registerSchema,
  loginSchema,
  profileSchema,
  goalSchema,
  foodSchema,
} from '../utils/validation.js';
import {
  authenticate,
  issueSession,
  cookieName,
  cookieOptions,
  publicUser,
} from '../middleware/auth.js';
import { bmi, roadmap } from '../utils/calculations.js';
import * as records from '../controllers/records.js';
import { nutritionPlan } from '../services/nutritionPlan.js';
import { geminiExplanation } from '../services/gemini.js';
import { usdaSearch } from '../services/foodSearch.js';
export function api(settings) {
  const router = Router();
  const authLimit = rateLimit({
    windowMs: 15 * 60000,
    limit: 40,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Too many attempts. Please try again in 15 minutes.' },
  });
  router.post('/auth/register', authLimit, async (req, res) => {
    const { name, email, password } = registerSchema.parse(req.body);
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, passwordHash });
    issueSession(res, user, settings);
    res.status(201).json({ data: publicUser(user) });
  });
  router.post('/auth/login', authLimit, async (req, res) => {
    const { email, password } = loginSchema.parse(req.body);
    const user = await User.findOne({ email }).select('+passwordHash');
    const valid = await bcrypt.compare(
      password,
      user?.passwordHash || '$2b$12$tC.YjwWP2TZhMCusWpGFquplh/bRN4wxGcXEdQXmll7OGSnxN9F3q',
    );
    if (!user || !valid) return res.status(401).json({ error: 'Email or password is incorrect.' });
    issueSession(res, user, settings);
    res.json({ data: publicUser(user) });
  });
  router.use(authenticate(settings.secret));
  router.get('/auth/me', (req, res) => res.json({ data: publicUser(req.user) }));
  router.post('/auth/logout', async (req, res) => {
    await User.updateOne({ _id: req.user._id }, { $inc: { sessionVersion: 1 } });
    res.clearCookie(cookieName, cookieOptions(settings.production));
    res.json({ data: { loggedOut: true } });
  });
  router.get('/profile', async (req, res) => {
    const data = await LifestyleProfile.findOne({ user: req.user._id }).lean();
    res.json({
      data: data
        ? { ...data, bmi: bmi(data.weight, data.height, data.age, data), roadmap: roadmap(data) }
        : null,
    });
  });
  router.put('/profile', async (req, res) => {
    const { applyGoals, calorieGoal, proteinGoal, waterGoal, sleepGoal, ...data } =
      profileSchema.parse(req.body);
    let chosenGoals = null;
    if (applyGoals) {
      const current = await WellnessGoal.findOne({ user: req.user._id }).lean();
      chosenGoals = goalSchema.parse({
        water: waterGoal ?? current?.water ?? 2000,
        sleep: sleepGoal ?? current?.sleep ?? 8,
        calories: calorieGoal === undefined ? (current?.calories ?? null) : calorieGoal,
        protein: proteinGoal === undefined ? (current?.protein ?? null) : proteinGoal,
        weeklyWorkouts: current?.weeklyWorkouts ?? 3,
      });
    }
    const profile = await LifestyleProfile.findOneAndUpdate(
      { user: req.user._id },
      { $set: data },
      { upsert: true, new: true, runValidators: true, setDefaultsOnInsert: true },
    );
    if (chosenGoals)
      await WellnessGoal.findOneAndUpdate(
        { user: req.user._id },
        { $set: chosenGoals },
        { upsert: true, runValidators: true },
      );
    await User.updateOne({ _id: req.user._id }, { $set: { onboarded: true } });
    res.json({
      data: {
        ...profile.toObject(),
        bmi: bmi(data.weight, data.height, data.age, data),
        roadmap: roadmap(data),
      },
    });
  });
  router.get('/roadmap', async (req, res) => {
    const profile = await LifestyleProfile.findOne({ user: req.user._id }).lean();
    res.json({ data: profile ? roadmap(profile) : null });
  });
  router.get('/goals', async (req, res) =>
    res.json({
      data: (await WellnessGoal.findOne({ user: req.user._id }).lean()) || {
        water: 2000,
        sleep: 8,
        weeklyWorkouts: 3,
        calories: null,
        protein: null,
      },
    }),
  );
  router.put('/goals', async (req, res) => {
    const data = goalSchema.parse(req.body);
    res.json({
      data: await WellnessGoal.findOneAndUpdate(
        { user: req.user._id },
        { $set: data },
        { upsert: true, new: true, runValidators: true },
      ),
    });
  });
  router.get('/foods', async (req, res) =>
    res.json({
      data: await Food.find({ $or: [{ user: null }, { user: req.user._id }] })
        .sort({ name: 1 })
        .limit(1000)
        .lean(),
    }),
  );
  router.get('/nutrition-plan', async (req, res) => {
    const [profile, goals] = await Promise.all([
      LifestyleProfile.findOne({ user: req.user._id }).lean(),
      WellnessGoal.findOne({ user: req.user._id }).lean(),
    ]);
    res.json({
      data: profile
        ? { ...nutritionPlan(profile, goals || {}), geminiConfigured: Boolean(settings.geminiKey) }
        : null,
    });
  });
  router.post('/nutrition-plan/preview', async (req, res) => {
    const profile = profileSchema.parse(req.body);
    res.json({
      data: {
        ...nutritionPlan(profile, { calories: profile.calorieGoal ?? null }),
        geminiConfigured: Boolean(settings.geminiKey),
      },
    });
  });
  router.post(
    '/nutrition-plan/explain',
    rateLimit({
      windowMs: 15 * 60000,
      limit: 10,
      keyGenerator: (req) => String(req.user._id),
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      message: { error: 'Please wait before requesting another explanation.' },
    }),
    async (req, res) => {
      if (req.body.consent !== true)
        return res.status(400).json({
          error:
            'Choose the Gemini explanation action to allow sharing the derived estimate with Google.',
        });
      const profile = req.body.profile
        ? profileSchema.parse(req.body.profile)
        : await LifestyleProfile.findOne({ user: req.user._id }).lean();
      if (!profile) return res.status(422).json({ error: 'Complete your profile first.' });
      const goals = await WellnessGoal.findOne({ user: req.user._id }).lean();
      const plan = nutritionPlan(profile, goals || {});
      try {
        res.json({ data: await geminiExplanation(plan, settings) });
      } catch {
        res.status(502).json({
          error:
            'Gemini is unavailable. Your calculated estimate and chosen goals have not changed.',
        });
      }
    },
  );
  router.get('/foods/search', async (req, res) => {
    const q = String(req.query.q || '')
      .trim()
      .slice(0, 100);
    if (q.length < 2) return res.json({ data: [], onlineConfigured: Boolean(settings.usdaKey) });
    const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const local = await Food.find({
      $and: [
        { $or: [{ user: null }, { user: req.user._id }] },
        { name: { $regex: escaped, $options: 'i' } },
      ],
    })
      .sort({ name: 1 })
      .limit(30)
      .lean();
    let online = { foods: [], configured: Boolean(settings.usdaKey) },
      warning = null;
    try {
      online = await usdaSearch(q, settings.usdaKey);
    } catch (e) {
      warning = e.message;
    }
    res.json({ data: [...local, ...online.foods], onlineConfigured: online.configured, warning });
  });
  router.post('/foods', async (req, res) =>
    res
      .status(201)
      .json({ data: await Food.create({ ...foodSchema.parse(req.body), user: req.user._id }) }),
  );
  router.use('/:module', (req, res, next) => {
    if (
      (settings.projectPhase || 1) === 1 &&
      ['workouts', 'journal', 'weight'].includes(req.params.module)
    )
      return res.status(404).json({ error: 'This module is not enabled in this build.' });
    next();
  });
  router.get('/:module', records.resource, records.list);
  router.post('/:module', records.resource, records.create);
  router.get('/:module/:id', records.resource, records.get);
  router.put('/:module/:id', records.resource, records.update);
  router.delete('/:module/:id', records.resource, records.remove);
  return router;
}
