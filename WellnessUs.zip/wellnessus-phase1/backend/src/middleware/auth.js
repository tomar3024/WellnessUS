import jwt from 'jsonwebtoken';
import { User } from '../models/index.js';
export const cookieName = 'wellnessus_session';
export const cookieOptions = (production) => ({
  httpOnly: true,
  secure: production,
  sameSite: 'strict',
  path: '/',
});
export function authenticate(secret) {
  return async (req, res, next) => {
    try {
      const payload = jwt.verify(req.cookies[cookieName] || '', secret, {
        algorithms: ['HS256'],
        issuer: 'wellnessus',
        audience: 'wellnessus-web',
      });
      const user = await User.findById(payload.sub);
      if (!user || payload.v !== user.sessionVersion)
        return res.status(401).json({ error: 'Please sign in again.' });
      req.user = user;
      next();
    } catch (error) {
      if (error.name === 'MongoServerSelectionError') return next(error);
      res.status(401).json({ error: 'Please sign in to continue.' });
    }
  };
}
export function issueSession(res, user, settings) {
  const token = jwt.sign({ v: user.sessionVersion }, settings.secret, {
    subject: String(user._id),
    expiresIn: '7d',
    algorithm: 'HS256',
    issuer: 'wellnessus',
    audience: 'wellnessus-web',
  });
  res.cookie(cookieName, token, { ...cookieOptions(settings.production), maxAge: 7 * 86400000 });
}
export const publicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  onboarded: user.onboarded,
});
