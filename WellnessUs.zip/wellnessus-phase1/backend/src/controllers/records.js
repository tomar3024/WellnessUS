import mongoose from 'mongoose';
import { records } from '../models/index.js';
import { schemas, date } from '../utils/validation.js';
import { nutrition, sleepHours } from '../utils/calculations.js';
import { stampNow } from '../utils/time.js';
import { assertSleepDay, withSleepWrite } from '../utils/sleepLimits.js';
export function resource(req, res, next) {
  req.Model = records[req.params.module];
  req.schema = schemas[req.params.module];
  if (!req.Model) return res.status(404).json({ error: 'Unknown tracking module.' });
  next();
}
export function enrich(module, data) {
  if (module === 'meals') data.totals = nutrition(data.items);
  if (module === 'sleep') data.hours = sleepHours(data.bedtime, data.wakeTime);
  return data;
}
export async function list(req, res) {
  const query = { user: req.user._id };
  if (req.query.from || req.query.to) {
    query.date = {};
    if (req.query.from) query.date.$gte = date.parse(req.query.from);
    if (req.query.to) query.date.$lte = date.parse(req.query.to);
  }
  const page = Math.max(1, Math.min(100000, Number(req.query.page) || 1));
  const limit = Math.max(1, Math.min(500, Number(req.query.limit) || 200));
  if (req.params.module === 'journal' && req.query.search) {
    const escaped = String(req.query.search)
      .slice(0, 200)
      .replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    query.$or = [
      { title: { $regex: escaped, $options: 'i' } },
      { content: { $regex: escaped, $options: 'i' } },
    ];
  }
  const [data, total] = await Promise.all([
    req.Model.find(query)
      .sort({ date: -1, createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean(),
    req.Model.countDocuments(query),
  ]);
  res.json({ data, total, page, limit });
}
export async function create(req, res) {
  const data = enrich(req.params.module, req.schema.parse(req.body));
  if (['meals', 'water'].includes(req.params.module)) Object.assign(data, stampNow(data.timeZone));
  const save = async () => {
    if (req.params.module === 'sleep')
      assertSleepDay(await req.Model.find({ user: req.user._id, date: data.date }).lean(), data);
    res.status(201).json({ data: await req.Model.create({ ...data, user: req.user._id }) });
  };
  return req.params.module === 'sleep' ? withSleepWrite(req.user._id, save) : save();
}
export async function get(req, res) {
  if (!mongoose.isValidObjectId(req.params.id))
    return res.status(404).json({ error: 'Record not found.' });
  const data = await req.Model.findOne({ _id: req.params.id, user: req.user._id }).lean();
  if (!data) return res.status(404).json({ error: 'Record not found.' });
  res.json({ data });
}
export async function update(req, res) {
  if (!mongoose.isValidObjectId(req.params.id))
    return res.status(404).json({ error: 'Record not found.' });
  const data = enrich(req.params.module, req.schema.parse(req.body));
  if (['meals', 'water'].includes(req.params.module)) {
    const existing = await req.Model.findOne({ _id: req.params.id, user: req.user._id }).lean();
    if (!existing) return res.status(404).json({ error: 'Record not found.' });
    Object.assign(data, {
      date: existing.date,
      recordedAt: existing.recordedAt || existing.createdAt,
      timeZone: existing.timeZone || 'UTC',
    });
  }
  const save = async () => {
    if (req.params.module === 'sleep') {
      if (!(await req.Model.exists({ _id: req.params.id, user: req.user._id })))
        return res.status(404).json({ error: 'Record not found.' });
      assertSleepDay(
        await req.Model.find({ user: req.user._id, date: data.date }).lean(),
        data,
        req.params.id,
      );
    }
    const record = await req.Model.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { $set: data },
      { new: true, runValidators: true },
    );
    if (!record) return res.status(404).json({ error: 'Record not found.' });
    res.json({ data: record });
  };
  return req.params.module === 'sleep' ? withSleepWrite(req.user._id, save) : save();
}
export async function remove(req, res) {
  if (!mongoose.isValidObjectId(req.params.id))
    return res.status(404).json({ error: 'Record not found.' });
  const removeRecord = async () => {
    const record = await req.Model.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!record) return res.status(404).json({ error: 'Record not found.' });
    res.json({ data: { deleted: true } });
  };
  return req.params.module === 'sleep'
    ? withSleepWrite(req.user._id, removeRecord)
    : removeRecord();
}
