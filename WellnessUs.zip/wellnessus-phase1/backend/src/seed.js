import mongoose from 'mongoose';
import { config } from './config/index.js';
import { Food } from './models/index.js';
const foods = [
  ['Roti / chapati', '1 medium (40 g)', 120, 3.5, 22, 3],
  ['Cooked rice', '1 cup (150 g)', 195, 4, 43, 0.5],
  ['Dal, cooked', '1 cup (200 g)', 210, 12, 32, 4],
  ['Idli', '2 pieces (100 g)', 146, 4, 30, 1],
  ['Plain dosa', '1 medium (100 g)', 170, 4, 29, 5],
  ['Poha', '1 bowl (150 g)', 230, 5, 40, 6],
  ['Paneer', '100 g', 265, 18, 3, 20],
  ['Chickpeas, cooked', '1 cup (165 g)', 269, 14.5, 45, 4],
  ['Curd, plain', '1 bowl (150 g)', 92, 5.3, 7, 5],
  ['Sambar', '1 cup (200 g)', 130, 6, 20, 3],
  ['Vegetable sabzi', '1 bowl (150 g)', 150, 4, 18, 7],
  ['Upma', '1 bowl (150 g)', 220, 5, 35, 7],
  ['Banana', '1 medium (118 g)', 105, 1.3, 27, 0.4],
  ['Apple', '1 medium (180 g)', 95, 0.5, 25, 0.3],
  ['Egg, boiled', '1 large (50 g)', 78, 6.3, 0.6, 5.3],
  ['Chicken breast, cooked', '100 g', 165, 31, 0, 3.6],
  ['Oats, dry', '40 g', 156, 6.8, 26.5, 2.8],
  ['Milk', '1 glass (250 ml)', 153, 8, 12, 8],
  ['Almonds', '28 g', 164, 6, 6, 14],
  ['Tofu', '100 g', 144, 17, 3, 9],
  ['Whole wheat bread', '2 slices (60 g)', 150, 6, 26, 2],
  ['Peanut butter', '1 tablespoon (16 g)', 94, 4, 3, 8],
  ['Rajma, cooked', '1 cup (180 g)', 225, 13, 37, 2],
  ['Fish, cooked', '100 g', 160, 24, 0, 7],
];
const fiberValues = [
  3, 0.6, 8, 1, 1, 2, 0, 12.5, 0, 4, 5, 2, 3.1, 4.4, 0, 0, 4, 0, 3.5, 2, 4, 1, 11, 0,
];
await mongoose.connect(config().mongo);
for (const [index, [name, serving, calories, protein, carbs, fat]] of foods.entries())
  await Food.updateOne(
    { name, user: null },
    {
      $set: {
        serving,
        calories,
        protein,
        carbs,
        fat,
        fiber: fiberValues[index] ?? null,
        estimated: true,
      },
    },
    { upsert: true, runValidators: true },
  );
console.log(
  `Seeded ${foods.length} estimated food references. Existing user records were preserved.`,
);
await mongoose.disconnect();
