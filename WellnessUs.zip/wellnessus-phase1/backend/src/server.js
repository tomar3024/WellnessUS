import mongoose from 'mongoose';
import { config } from './config/index.js';
import { createApp } from './app.js';
const settings = config();
await mongoose.connect(settings.mongo, { serverSelectionTimeoutMS: 10000 });
const server = createApp(settings).listen(settings.port, () =>
  console.log(`WellnessUs API: http://localhost:${settings.port}`),
);
for (const signal of ['SIGINT', 'SIGTERM'])
  process.on(signal, () =>
    server.close(async () => {
      await mongoose.disconnect();
      process.exit(0);
    }),
  );
