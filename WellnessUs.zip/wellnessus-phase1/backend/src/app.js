import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';
import { ZodError } from 'zod';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import { api } from './routes/api.js';
export function createApp(settings) {
  const app = express();
  app.disable('x-powered-by');
  app.use(
    helmet({
      contentSecurityPolicy: settings.production
        ? {
            directives: {
              'img-src': ["'self'", 'data:'],
              'style-src': ["'self'", "'unsafe-inline'"],
              'script-src': ["'self'"],
            },
          }
        : false,
    }),
  );
  app.use(cors({ origin: settings.origin, credentials: true }));
  app.use(express.json({ limit: '128kb' }));
  app.use(cookieParser());
  app.use(
    '/api',
    rateLimit({
      windowMs: 60000,
      limit: 300,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
      message: { error: 'Too many requests. Try again shortly.' },
    }),
  );
  app.use('/api', (req, res, next) => {
    if (
      !['GET', 'HEAD', 'OPTIONS'].includes(req.method) &&
      ((req.headers.origin && req.headers.origin !== settings.origin) ||
        req.headers['sec-fetch-site'] === 'cross-site')
    )
      return res.status(403).json({ error: 'Request origin is not allowed.' });
    next();
  });
  app.get('/api/health', (req, res) => res.json({ data: { status: 'ok' } }));
  app.use('/api', api(settings));
  app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint not found.' }));
  const dist = fileURLToPath(new URL('../../frontend/dist/', import.meta.url));
  if (existsSync(dist)) {
    app.use(express.static(dist));
    app.get('/{*splat}', (req, res) => res.sendFile(path.join(dist, 'index.html')));
  }
  app.use((err, req, res, next) => {
    if (err.code === 'SLEEP_LIMIT') return res.status(422).json({ error: err.message });
    if (err instanceof ZodError)
      return res.status(422).json({
        error: err.issues.map((i) => `${i.path.join('.') || 'Input'}: ${i.message}`).join('; '),
      });
    if (err.code === 11000)
      return res.status(409).json({ error: 'An account with that email already exists.' });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON.' });
    if (err.type === 'entity.too.large')
      return res.status(413).json({ error: 'Request is too large.' });
    if (err.name === 'ValidationError' || err.name === 'CastError')
      return res.status(422).json({ error: 'Please check your input values.' });
    console.error(err.name, err.message);
    res.status(500).json({ error: 'Unable to complete the request. Please try again.' });
  });
  return app;
}
