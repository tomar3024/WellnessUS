import { bmi } from '../utils/calculations.js';
const round10 = (n) => Math.round(n / 10) * 10;
export function nutritionPlan(profile, goals = {}) {
  const rawBmi = profile.weight / (profile.height / 100) ** 2;
  let blocked =
    profile.age < 18 ||
    profile.age > 78 ||
    profile.pregnancyStatus === 'Pregnant' ||
    profile.breastfeeding ||
    profile.eatingConcern ||
    profile.unintentionalWeightChange ||
    Boolean(profile.healthContext?.trim()) ||
    rawBmi < 16 ||
    rawBmi >= 40;
  const sexKnown = ['Male', 'Female'].includes(profile.sex);
  const result = bmi(profile.weight, profile.height, profile.age, profile);
  let estimate = null;
  if (!blocked && sexKnown) {
    const bmr =
      10 * profile.weight +
      6.25 * profile.height -
      5 * profile.age +
      (profile.sex === 'Male' ? 5 : -161);
    const factor =
      {
        'Mostly sedentary': 1.2,
        'Lightly active': 1.375,
        'Moderately active': 1.55,
        'Very active': 1.725,
      }[profile.activity] || 1.2;
    const maintenance = round10(bmr * factor);
    estimate = {
      maintenance,
      low: round10(maintenance * 0.9),
      high: round10(maintenance * 1.1),
      bmr: Math.round(bmr),
      activityFactor: factor,
      method: 'Mifflin–St Jeor × approximate activity factor',
      source: 'https://pubmed.ncbi.nlm.nih.gov/2305711/',
    };
    if (maintenance < 1200 || maintenance > 6000) {
      estimate = null;
      blocked = true;
    }
  }
  const primaryGoal = profile.primaryGoal || '';
  const secondaryGoal = profile.secondaryGoal || 'None for now';
  const goalsText = `${primaryGoal} ${secondaryGoal}`.toLowerCase();
  const muscleFocus = goalsText.includes('muscle') || goalsText.includes('strength');
  const gainFocus = ['Gain weight', 'Gain weight and build muscle', 'Gain a little weight'].some(
    (goal) => primaryGoal === goal || secondaryGoal === goal,
  );
  const smallSurplusChosen =
    muscleFocus &&
    !gainFocus &&
    result.code === 'healthy' &&
    primaryGoal !== 'Discuss gradual fat loss' &&
    profile.energyPreference === 'Consider a small surplus';
  const intent =
    gainFocus || smallSurplusChosen
      ? 'Gradually gain weight'
      : primaryGoal === 'Discuss gradual fat loss'
        ? 'Discuss gradual weight loss'
        : primaryGoal
          ? 'Maintain my current routine'
          : profile.nutritionIntent || 'Maintain my current routine';
  let approach = 'maintain';
  let explanation =
    'Maintenance means roughly matching energy intake to energy use. Your goal stays your choice.';
  if (blocked) {
    approach = 'professional-support';
    explanation =
      'Your answers call for individualized support. This app will not generate a calorie estimate or weight-change suggestion for this situation.';
  } else if (result.code === 'underweight') {
    approach = 'consider-surplus';
    explanation =
      'Your adult BMI is below the standard range. A gradual surplus may be appropriate if you want to gain weight; discuss the reason for low weight and a suitable plan with a qualified professional. A deficit is not suggested.';
  } else if (
    intent === 'Discuss gradual weight loss' &&
    ['overweight', 'obesity'].includes(result.code)
  ) {
    approach = 'consider-deficit';
    explanation =
      'You selected a weight-loss discussion goal. A modest deficit can be an option for some adults, but BMI alone does not establish a suitable target. Review your estimate and choose a goal with appropriate support.';
  } else if (intent === 'Gradually gain weight') {
    approach = 'consider-surplus';
    explanation =
      'You selected gradual weight gain. A surplus means eating above maintenance; choose a suitable goal with individual guidance rather than following an automatic BMI-based adjustment.';
  }
  if (!blocked && !sexKnown)
    explanation +=
      ' A sex-specific equation is not applied because you did not select Male or Female; you can still enter a goal yourself.';
  let calorieAdjustment = 0;
  if (estimate && primaryGoal) {
    if (gainFocus) calorieAdjustment = result.code === 'underweight' ? 300 : 150;
    else if (smallSurplusChosen) calorieAdjustment = 150;
    else if (
      primaryGoal === 'Discuss gradual fat loss' &&
      ['overweight', 'obesity'].includes(result.code)
    )
      calorieAdjustment = -200;
  }
  const suggestedCalories = estimate ? round10(estimate.maintenance + calorieAdjustment) : null;
  const planningCalories = goals.calories ?? suggestedCalories;
  const regularlyActive = profile.exerciseFrequency && profile.exerciseFrequency !== 'Never';
  const proteinRate = muscleFocus ? (regularlyActive ? 1.6 : 1.2) : gainFocus ? 1.2 : 0.8;
  const suggestedProtein =
    estimate && primaryGoal && profile.age >= 19
      ? Math.max(
          1,
          Math.round(Math.min(profile.weight * proteinRate, (planningCalories * 0.35) / 4)),
        )
      : null;
  const suggestionReason = primaryGoal
    ? `${primaryGoal}${secondaryGoal !== 'None for now' ? ` + ${secondaryGoal}` : ''}. ${calorieAdjustment > 0 ? `An illustrative ${calorieAdjustment} kcal surplus` : calorieAdjustment < 0 ? `An illustrative ${Math.abs(calorieAdjustment)} kcal deficit` : 'A maintenance starting point'} follows your selected goals, not BMI alone. Review these references before saving.`
    : 'Start around estimated maintenance, then choose a goal yourself.';
  const calories = goals.calories ?? null;
  const macroEligible = !blocked && profile.age >= 19 && Number.isFinite(calories) && calories > 0;
  const ratio =
    profile.nutritionPreference === 'Protein awareness'
      ? { protein: 0.25, carbs: 0.45, fat: 0.3 }
      : { protein: 0.2, carbs: 0.5, fat: 0.3 };
  const references = macroEligible
    ? {
        protein: {
          target: goals.protein || suggestedProtein || Math.round((calories * ratio.protein) / 4),
          low: Math.round((calories * 0.1) / 4),
          high: Math.round((calories * 0.35) / 4),
        },
        carbs: {
          target: Math.round((calories * ratio.carbs) / 4),
          low: Math.round((calories * 0.45) / 4),
          high: Math.round((calories * 0.65) / 4),
        },
        fat: {
          target: Math.round((calories * ratio.fat) / 9),
          low: Math.round((calories * 0.2) / 9),
          high: Math.round((calories * 0.35) / 9),
        },
        fiber: { target: Math.round((calories / 1000) * 14), low: null, high: null },
      }
    : null;
  return {
    estimate,
    primaryGoal,
    secondaryGoal,
    suggestedGoals: {
      calories: suggestedCalories,
      protein: suggestedProtein,
      calorieAdjustment: estimate ? calorieAdjustment : null,
      reason: blocked ? explanation : suggestionReason,
      proteinReason: suggestedProtein
        ? `${proteinRate} g/kg × ${profile.weight} kg for your selected focus and current activity, bounded by the calorie reference. This is an optional adult planning example. Muscle and strength gains also require appropriate training; protein alone does not guarantee them.`
        : 'No automatic protein reference is generated for this context.',
      source: 'https://pmc.ncbi.nlm.nih.gov/articles/PMC5477153/',
    },
    approach,
    explanation,
    references,
    goal: calories,
    bmi: result,
    eligible: Boolean(estimate),
    referenceNote:
      'Optional planning references derived from your chosen calorie goal and adult dietary reference ranges; they are not a diagnosis or an individual prescription.',
    referenceSource: 'https://www.ncbi.nlm.nih.gov/books/NBK221374/',
    fiberSource: 'https://health.gov/sites/default/files/2019-09/15-Appendix-E-3.pdf',
  };
}
