export function normalizeUsdaFood(food) {
  const get = (...ids) => {
    for (const id of ids) {
      const item = (food.foodNutrients || []).find(
        (n) => n.nutrientId === id || n.nutrient?.id === id,
      );
      const value = item?.value ?? item?.amount;
      if (Number.isFinite(value)) return value;
    }
    return null;
  };
  const calories = get(1008, 2047, 2048);
  const protein = get(1003),
    carbs = get(1005),
    fat = get(1004);
  if ([calories, protein, carbs, fat].some((n) => n === null)) return null;
  return {
    _id: `usda-${food.fdcId}`,
    name: food.description,
    serving: '100 g',
    calories,
    protein,
    carbs,
    fat,
    fiber: get(1079),
    source: 'USDA FoodData Central',
    sourceUrl: `https://fdc.nal.usda.gov/food-details/${food.fdcId}/nutrients`,
    estimated: true,
  };
}
export async function usdaSearch(query, key, fetcher = fetch) {
  if (!key) return { foods: [], configured: false };
  const response = await fetcher('https://api.nal.usda.gov/fdc/v1/foods/search', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': key },
    body: JSON.stringify({
      query,
      pageSize: 15,
      dataType: ['Foundation', 'SR Legacy', 'Survey (FNDDS)'],
    }),
    signal: AbortSignal.timeout(12000),
  });
  if (!response.ok)
    throw new Error(
      'The online food database is unavailable. You can still use the saved library.',
    );
  const result = await response.json();
  return { foods: (result.foods || []).map(normalizeUsdaFood).filter(Boolean), configured: true };
}
