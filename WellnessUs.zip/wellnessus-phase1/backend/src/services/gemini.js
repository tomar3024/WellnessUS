import { z } from 'zod';
const explanationSchema = z.object({ summary: z.string().min(1).max(1000) }).strict();
export async function geminiExplanation(plan, settings, fetcher = fetch) {
  if (!settings.geminiKey)
    return {
      provider: 'calculation',
      available: false,
      summary: plan.explanation,
      reason: 'Gemini is not configured. The calculation-based estimate is available.',
    };
  if (!plan.estimate)
    return {
      provider: 'calculation',
      available: false,
      summary: plan.explanation,
      reason: 'No AI calorie estimate is generated for this profile.',
    };
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(settings.geminiModel || 'gemini-3.5-flash-lite')}:generateContent`;
  // Only derived estimates and a coarse goal direction are sent, never identity, journal or health notes.
  const response = await fetcher(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': settings.geminiKey },
    signal: AbortSignal.timeout(15000),
    body: JSON.stringify({
      systemInstruction: {
        parts: [
          {
            text: 'You explain an educational wellness calculation. Return JSON with a single summary string of at most 120 words. Use the supplied maintenance range as an uncertain estimate. Explain the supplied approach in plain language. Do not invent numbers, prescribe calorie changes, diagnose health, recommend weight-loss rates or override the user. Do not mention phase labels. Never claim the estimate is exact.',
          },
        ],
      },
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: JSON.stringify({
                estimatedMaintenance: plan.estimate,
                approach: plan.approach,
                explanation: plan.explanation,
              }),
            },
          ],
        },
      ],
      generationConfig: {
        responseMimeType: 'application/json',
        temperature: 0.2,
        maxOutputTokens: 400,
      },
    }),
  });
  if (!response.ok)
    throw new Error(
      'Gemini could not complete this request. Your calculation-based estimate is unchanged.',
    );
  const result = await response.json();
  const text = result.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  const explanation = explanationSchema.parse(JSON.parse(text));
  return {
    provider: 'Gemini',
    available: true,
    summary: explanation.summary,
    model: settings.geminiModel || 'gemini-3.5-flash-lite',
  };
}
