import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assertSleepDay, durationMinutes, sleepDaySummary } from '../src/utils/sleepLimits.js';
const date = '2026-11-03';
test('Sleep limit uses exact minutes and permits exactly 24 hours across two sessions', () => {
  const first = { _id: 'a', date, bedtime: '18:00', wakeTime: '12:00' };
  assert.equal(durationMinutes(first.bedtime, first.wakeTime), 1080);
  assert.equal(assertSleepDay([first], { date, bedtime: '12:00', wakeTime: '18:00' }), 1440);
  assert.throws(
    () => assertSleepDay([first], { date, bedtime: '12:00', wakeTime: '18:01' }),
    /24 hours/,
  );
  assert.equal(
    sleepDaySummary([first, { date, bedtime: '12:00', wakeTime: '19:00' }]).valid,
    false,
  );
});
test('Sleep cap rejects a third entry and excludes the original record while editing', () => {
  const entries = [
    { _id: 'a', date, bedtime: '22:00', wakeTime: '06:00' },
    { _id: 'b', date, bedtime: '13:00', wakeTime: '14:00' },
  ];
  assert.throws(
    () => assertSleepDay(entries, { date, bedtime: '16:00', wakeTime: '17:00' }),
    /two sleep sessions/,
  );
  assert.equal(assertSleepDay(entries, { date, bedtime: '21:00', wakeTime: '06:00' }, 'a'), 600);
  assert.equal(
    assertSleepDay(entries, { date: '2026-11-04', bedtime: '22:00', wakeTime: '06:00' }),
    480,
  );
});
