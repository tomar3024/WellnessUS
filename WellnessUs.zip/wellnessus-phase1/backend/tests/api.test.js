import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { User, LifestyleProfile } from '../src/models/index.js';
import { stampNow } from '../src/utils/time.js';
let mongo,
  app,
  counter = 0;
const settings = {
  secret: 'test-only-secret-with-at-least-32-characters',
  origin: 'http://localhost:5173',
  production: false,
  projectPhase: 2,
};
const profile = {
  age: 22,
  sex: 'Female',
  height: 175,
  weight: 70,
  objective: 'Improve general health',
  activity: 'Moderately active',
  exerciseFrequency: '3–4 days',
  averageSleep: 8,
  mealConsistency: 'Sometimes consistent',
  hydrationConsistency: 'Getting started',
  activityPreferences: [],
  nutritionPreference: 'Balanced tracking',
  healthContext: '',
  unintentionalWeightChange: false,
  pregnancyStatus: 'Not pregnant',
  timeZone: 'Asia/Kolkata',
};
const entries = {
  water: { date: '1999-01-01', timeZone: 'Asia/Kolkata', amount: 250 },
  meals: {
    date: '1999-01-01',
    timeZone: 'Asia/Kolkata',
    type: 'Lunch',
    items: [
      { name: 'Dal', serving: '1 cup', quantity: 2, calories: 210, protein: 12, carbs: 32, fat: 4 },
    ],
  },
  sleep: { date: '2026-11-03', bedtime: '23:00', wakeTime: '07:00', notes: 'Restful' },
  workouts: {
    date: '2026-11-03',
    type: 'Strength',
    duration: 30,
    exercises: [{ name: 'Squat', sets: 3, reps: 10 }],
    notes: 'Comfortable pace',
  },
  journal: {
    date: '2026-11-03',
    title: 'A quiet morning',
    content: 'Enjoyed a walk.',
    mood: 'Good',
  },
};
before(async () => {
  mongo = process.env.TEST_MONGODB_URI
    ? null
    : await MongoMemoryServer.create({
        instance: { dbPath: process.env.TEST_DB_PATH, args: ['--wiredTigerCacheSizeGB', '0.25'] },
      });
  await mongoose.connect(
    process.env.TEST_MONGODB_URI || mongo.getUri(`wellnessus_test_${Date.now()}`),
  );
  await User.init();
  await LifestyleProfile.init();
  app = createApp(settings);
});
after(async () => {
  await mongoose.disconnect();
  if (mongo) await mongo.stop();
});
async function account(application = app) {
  const agent = request.agent(application);
  const response = await agent.post('/api/auth/register').send({
    name: 'Test Person',
    email: `person${++counter}@example.com`,
    password: 'a-secure-test-password',
  });
  assert.equal(response.status, 201);
  return {
    agent,
    user: response.body.data,
    cookie: response.headers['set-cookie'][0].split(';')[0],
  };
}
test('Registration, bcrypt, login, duplicate protection, session cookie and logout revocation', async () => {
  const agent = request.agent(app),
    credentials = { name: 'Alex', email: 'alex@example.com', password: 'a-secure-test-password' };
  const registered = await agent.post('/api/auth/register').send(credentials);
  assert.equal(registered.status, 201);
  assert.equal(registered.body.data.passwordHash, undefined);
  assert.match(registered.headers['set-cookie'][0], /HttpOnly/);
  assert.match(registered.headers['set-cookie'][0], /SameSite=Strict/);
  const user = await User.findOne({ email: credentials.email }).select('+passwordHash');
  assert.notEqual(user.passwordHash, credentials.password);
  assert.match(user.passwordHash, /^\$2/);
  assert.equal((await request(app).post('/api/auth/register').send(credentials)).status, 409);
  assert.equal(
    (
      await request(app)
        .post('/api/auth/login')
        .send({ email: credentials.email, password: 'wrong-password' })
    ).status,
    401,
  );
  assert.equal(
    (
      await request(app)
        .post('/api/auth/login')
        .send({ email: credentials.email, password: credentials.password })
    ).status,
    200,
  );
  const old = registered.headers['set-cookie'][0].split(';')[0];
  assert.equal((await agent.post('/api/auth/logout')).status, 200);
  assert.equal((await request(app).get('/api/auth/me').set('Cookie', old)).status, 401);
});
test('Protected API, invalid token and cross-origin requests are rejected', async () => {
  assert.equal((await request(app).get('/api/water')).status, 401);
  assert.equal(
    (await request(app).get('/api/auth/me').set('Cookie', 'wellnessus_session=invalid')).status,
    401,
  );
  assert.equal(
    (
      await request(app)
        .post('/api/auth/register')
        .set('Origin', 'https://untrusted.example')
        .send({})
    ).status,
    403,
  );
});
test('Quiz, BMI, health context, pregnancy handling and roadmap persist privately', async () => {
  const first = await account(),
    second = await account();
  assert.equal((await first.agent.get('/api/profile')).body.data, null);
  const result = await first.agent.put('/api/profile').send(profile);
  assert.equal(result.status, 200);
  assert.equal(result.body.data.bmi.value, 22.9);
  assert.equal(result.body.data.bmi.category, 'Healthy BMI range');
  assert.equal(result.body.data.sex, 'Female');
  assert.equal(result.body.data.roadmap.steps.length, 4);
  assert.equal((await first.agent.get('/api/auth/me')).body.data.onboarded, true);
  assert.equal((await second.agent.get('/api/profile')).body.data, null);
  assert.equal((await second.agent.get('/api/roadmap')).body.data, null);
  const minor = await first.agent.put('/api/profile').send({ ...profile, age: 16 });
  assert.equal(minor.body.data.bmi.category, null);
  const pregnancy = await first.agent
    .put('/api/profile')
    .send({ ...profile, pregnancyStatus: 'Pregnant' });
  assert.equal(pregnancy.body.data.bmi.category, null);
  assert.equal(pregnancy.body.data.roadmap.bmi.code, 'pregnancy');
});
test('Calorie, water and sleep goals save and validate', async () => {
  const { agent } = await account();
  const goals = { water: 2250, sleep: 8.5, weeklyWorkouts: 3, calories: 2100, protein: null };
  assert.equal((await agent.put('/api/goals').send(goals)).status, 200);
  assert.equal((await agent.get('/api/goals')).body.data.calories, 2100);
  assert.equal((await agent.put('/api/goals').send({ ...goals, water: -50 })).status, 422);
});
for (const [module, entry] of Object.entries(entries))
  test(`${module}: CRUD, filtering and account isolation`, async () => {
    const first = await account(),
      second = await account(),
      automatic = ['meals', 'water'].includes(module);
    const before = Date.now();
    const created = await first.agent.post(`/api/${module}`).send(entry);
    assert.equal(created.status, 201);
    const r = created.body.data,
      id = r._id;
    if (automatic) {
      assert.equal(r.date, stampNow('Asia/Kolkata').date);
      assert.ok(new Date(r.recordedAt).getTime() >= before);
      assert.equal(r.timeZone, 'Asia/Kolkata');
    }
    if (module === 'sleep') assert.equal(r.hours, 8);
    if (module === 'meals')
      assert.deepEqual(r.totals, {
        calories: 420,
        protein: 24,
        carbs: 64,
        fat: 8,
        fiber: 0,
        fiberComplete: false,
      });
    assert.equal((await first.agent.get(`/api/${module}/${id}`)).status, 200);
    assert.equal((await second.agent.get(`/api/${module}/${id}`)).status, 404);
    assert.equal((await second.agent.get(`/api/${module}`)).body.total, 0);
    assert.equal((await second.agent.put(`/api/${module}/${id}`).send(entry)).status, 404);
    assert.equal((await second.agent.delete(`/api/${module}/${id}`)).status, 404);
    const updated = await first.agent
      .put(`/api/${module}/${id}`)
      .send({ ...entry, date: '2026-11-02', ...(automatic ? { timeZone: 'UTC' } : {}) });
    assert.equal(updated.status, 200);
    assert.equal(updated.body.data.date, automatic ? r.date : '2026-11-02');
    if (automatic) {
      assert.equal(updated.body.data.recordedAt, r.recordedAt);
      assert.equal(updated.body.data.timeZone, r.timeZone);
    }
    const d = updated.body.data.date;
    assert.equal((await first.agent.get(`/api/${module}?from=${d}&to=${d}`)).body.total, 1);
    assert.equal(
      (await first.agent.post(`/api/${module}`).send({ ...entry, user: second.user.id })).status,
      422,
    );
    assert.equal((await first.agent.delete(`/api/${module}/${id}`)).status, 200);
    assert.equal((await first.agent.get(`/api/${module}`)).body.total, 0);
  });
test('Phase 1 blocks workout and journal APIs while core tracking remains available', async () => {
  const phase1 = createApp({ ...settings, projectPhase: 1 }),
    { agent } = await account(phase1);
  for (const m of ['workouts', 'journal', 'weight']) {
    assert.equal((await agent.get(`/api/${m}`)).status, 404);
    assert.equal((await agent.post(`/api/${m}`).send(entries[m] || {})).status, 404);
  }
  assert.equal(
    (await agent.post('/api/water').send({ amount: 250, timeZone: 'Asia/Kolkata' })).status,
    201,
  );
  assert.equal((await agent.get('/api/sleep')).status, 200);
});
test('Custom foods, journal search, pagination and invalid values', async () => {
  const first = await account(),
    second = await account();
  await first.agent
    .post('/api/foods')
    .send({ name: 'My oats', serving: '40 g', calories: 150, protein: 5, carbs: 25, fat: 3 });
  assert.equal((await first.agent.get('/api/foods')).body.data.length, 1);
  assert.equal((await second.agent.get('/api/foods')).body.data.length, 0);
  await first.agent.post('/api/journal').send(entries.journal);
  assert.equal((await first.agent.get('/api/journal?search=quiet')).body.total, 1);
  assert.equal((await first.agent.get('/api/journal?search=.*')).body.total, 0);
  assert.equal((await first.agent.post('/api/water').send({ amount: -1 })).status, 422);
  assert.equal(
    (await first.agent.post('/api/water').send({ amount: 250, timeZone: 'Not/AZone' })).status,
    422,
  );
  assert.equal(
    (await first.agent.post('/api/meals').send({ ...entries.meals, items: [] })).status,
    422,
  );
  assert.equal((await first.agent.get('/api/water?from=not-a-date')).status, 422);
  await first.agent.post('/api/water').send(entries.water);
  await first.agent.post('/api/water').send(entries.water);
  const page = await first.agent.get('/api/water?limit=1&page=2');
  assert.equal(page.body.total, 2);
  assert.equal(page.body.data.length, 1);
});

test('Adaptive plan preview, chosen goals, private food search and Gemini fallback', async () => {
  const { agent } = await account();
  const draft = await agent
    .post('/api/nutrition-plan/preview')
    .send({ ...profile, nutritionIntent: 'Gradually gain weight', weight: 50 });
  assert.equal(draft.status, 200);
  assert.equal(draft.body.data.approach, 'consider-surplus');
  assert.ok(draft.body.data.estimate.maintenance);
  assert.equal((await agent.get('/api/profile')).body.data, null);
  const saved = await agent
    .put('/api/profile')
    .send({ ...profile, applyGoals: true, calorieGoal: 2200, waterGoal: 2250, sleepGoal: 8.5 });
  assert.equal(saved.status, 200);
  assert.equal((await agent.get('/api/goals')).body.data.calories, 2200);
  const plan = await agent.get('/api/nutrition-plan');
  assert.equal(plan.status, 200);
  assert.equal(plan.body.data.goal, 2200);
  assert.ok(plan.body.data.references.fiber.target);
  assert.equal((await agent.post('/api/nutrition-plan/explain').send({})).status, 400);
  const explanation = await agent.post('/api/nutrition-plan/explain').send({ consent: true });
  assert.equal(explanation.status, 200);
  assert.equal(explanation.body.data.available, false);
  await agent.post('/api/foods').send({
    name: 'Personal lentil bowl',
    serving: '1 bowl',
    calories: 250,
    protein: 15,
    carbs: 30,
    fat: 6,
    fiber: 8,
  });
  const found = await agent.get('/api/foods/search?q=lentil');
  assert.equal(found.status, 200);
  assert.equal(found.body.data[0].fiber, 8);
  assert.equal(found.body.onlineConfigured, false);
});

test('Sleep API caps concurrent creates at two per day and allows a freed slot', async () => {
  const { agent } = await account(),
    date = '2026-10-20',
    entry = { date, bedtime: '12:00', wakeTime: '13:00', notes: '' };
  const responses = await Promise.all(
    Array.from({ length: 5 }, () => agent.post('/api/sleep').send(entry)),
  );
  assert.equal(responses.filter((r) => r.status === 201).length, 2);
  assert.equal(responses.filter((r) => r.status === 422).length, 3);
  const rows = (await agent.get(`/api/sleep?from=${date}&to=${date}`)).body.data;
  assert.equal(rows.length, 2);
  assert.equal((await agent.delete(`/api/sleep/${rows[0]._id}`)).status, 200);
  assert.equal((await agent.post('/api/sleep').send(entry)).status, 201);
  const current = (await agent.get(`/api/sleep?from=${date}&to=${date}`)).body.data;
  const edits = await Promise.all(
    current.map((row) => agent.put(`/api/sleep/${row._id}`).send({ ...entry, wakeTime: '02:00' })),
  );
  assert.equal(edits.filter((r) => r.status === 200).length, 1);
  assert.equal(edits.filter((r) => r.status === 422).length, 1);
  const another = await account();
  assert.equal((await another.agent.post('/api/sleep').send(entry)).status, 201);
});
test('Sleep API rejects more than 24 hours on creation, edit and date moves', async () => {
  const { agent } = await account(),
    date = '2026-10-21',
    first = { date, bedtime: '18:00', wakeTime: '12:00', notes: '' },
    second = { date, bedtime: '12:00', wakeTime: '18:00', notes: '' };
  assert.equal((await agent.post('/api/sleep').send(first)).status, 201);
  assert.equal((await agent.post('/api/sleep').send({ ...second, wakeTime: '19:00' })).status, 422);
  const saved = await agent.post('/api/sleep').send(second);
  assert.equal(saved.status, 201);
  assert.equal(
    (await agent.put(`/api/sleep/${saved.body.data._id}`).send({ ...second, wakeTime: '18:01' }))
      .status,
    422,
  );
  assert.equal((await agent.get(`/api/sleep/${saved.body.data._id}`)).body.data.hours, 6);
  const target = { date: '2026-10-22', bedtime: '12:00', wakeTime: '13:00', notes: '' };
  await agent.post('/api/sleep').send(target);
  await agent.post('/api/sleep').send(target);
  assert.equal(
    (await agent.put(`/api/sleep/${saved.body.data._id}`).send({ ...second, date: target.date }))
      .status,
    422,
  );
  assert.equal((await agent.get(`/api/sleep/${saved.body.data._id}`)).body.data.date, date);
});
test('Quiz saves primary and secondary goals plus explicitly confirmed protein', async () => {
  const { agent } = await account();
  const input = {
    ...profile,
    sex: 'Male',
    primaryGoal: 'Build muscle',
    secondaryGoal: 'Build strength',
    exerciseFrequency: '3–4 days',
    applyGoals: true,
    calorieGoal: 2400,
    proteinGoal: 112,
    waterGoal: 2250,
    sleepGoal: 8,
  };
  const saved = await agent.put('/api/profile').send(input);
  assert.equal(saved.status, 200);
  assert.equal(saved.body.data.primaryGoal, 'Build muscle');
  assert.equal(saved.body.data.secondaryGoal, 'Build strength');
  assert.equal((await agent.get('/api/goals')).body.data.protein, 112);
  assert.equal((await agent.get('/api/nutrition-plan')).body.data.references.protein.target, 112);
  assert.equal(
    (await agent.put('/api/profile').send({ ...input, secondaryGoal: 'Build muscle' })).status,
    422,
  );
});
