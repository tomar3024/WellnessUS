import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bmi, roadmap, nutrition, sleepHours } from '../src/utils/calculations.js';
import { stampNow, validTimeZone } from '../src/utils/time.js';
import { schemas } from '../src/utils/validation.js';
test('Adult BMI boundaries use unrounded values', () => {
  assert.equal(bmi(70, 175, 25).value, 22.9);
  for (const [weight, category] of [
    [18.49, 'Underweight'],
    [18.5, 'Healthy BMI range'],
    [24.96, 'Healthy BMI range'],
    [25, 'Overweight'],
    [29.99, 'Overweight'],
    [30, 'Obesity'],
  ])
    assert.equal(bmi(weight, 100, 25).category, category);
});
test('BMI and roadmap avoid adult labels for minors and pregnancy', () => {
  assert.equal(bmi(70, 175, 16).category, null);
  assert.equal(bmi(70, 175, 25, { pregnancyStatus: 'Pregnant' }).category, null);
  const p = { weight: 45, height: 175, age: 22, averageSleep: 7, healthContext: '' };
  const r = roadmap(p);
  assert.equal(r.bmi.code, 'underweight');
  assert.equal(r.steps.length, 4);
  assert.match(r.steps[0].title, /nourishment/);
  assert.equal(r.calorieTarget, undefined);
  assert.match(
    roadmap({ ...p, unintentionalWeightChange: true }).steps[3].detail,
    /healthcare review/,
  );
});
test('Nutrition multiplies all macros by servings', () => {
  assert.deepEqual(
    nutrition([
      { quantity: 2, calories: 120, protein: 4, carbs: 20, fat: 3 },
      { quantity: 0.5, calories: 200, protein: 10, carbs: 30, fat: 5 },
    ]),
    { calories: 340, protein: 13, carbs: 55, fat: 8.5, fiber: 0, fiberComplete: false },
  );
});
test('Sleep includes overnight, daytime and partial hours', () => {
  assert.equal(sleepHours('22:30', '06:30'), 8);
  assert.equal(sleepHours('13:00', '14:30'), 1.5);
  assert.equal(sleepHours('23:45', '07:15'), 7.5);
});
test('Date stamping respects local midnight and time zones', () => {
  assert.equal(stampNow('Asia/Kolkata', new Date('2026-11-03T18:29:59Z')).date, '2026-11-03');
  assert.equal(stampNow('Asia/Kolkata', new Date('2026-11-03T18:30:00Z')).date, '2026-11-04');
  assert.equal(
    stampNow('America/Los_Angeles', new Date('2026-11-03T01:00:00Z')).date,
    '2026-11-02',
  );
  assert.equal(validTimeZone('Not/AZone'), false);
});
test('Validation rejects invalid input and derived timestamp injection', () => {
  assert.equal(schemas.water.safeParse({ amount: -10 }).success, false);
  assert.equal(schemas.water.safeParse({ amount: 250, user: 'another-user' }).success, false);
  assert.equal(schemas.water.safeParse({ amount: 250, recordedAt: '1999-01-01' }).success, false);
  assert.equal(
    schemas.sleep.safeParse({ date: '2026-02-30', bedtime: '22:00', wakeTime: '07:00' }).success,
    false,
  );
  assert.equal(
    schemas.sleep.safeParse({ date: '2026-01-01', bedtime: '22:00', wakeTime: '22:00' }).success,
    false,
  );
});
