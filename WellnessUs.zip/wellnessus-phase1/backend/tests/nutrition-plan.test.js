import { test } from 'node:test';
import assert from 'node:assert/strict';
import { nutritionPlan } from '../src/services/nutritionPlan.js';
import { geminiExplanation } from '../src/services/gemini.js';
import { normalizeUsdaFood } from '../src/services/foodSearch.js';
import { nutrition } from '../src/utils/calculations.js';
const profile = {
  age: 25,
  sex: 'Male',
  height: 175,
  weight: 70,
  activity: 'Moderately active',
  pregnancyStatus: 'Not applicable',
  healthContext: '',
  nutritionPreference: 'Balanced tracking',
  nutritionIntent: 'Maintain my current routine',
};
test('Maintenance estimate follows Mifflin equation and explicit activity factor', () => {
  const plan = nutritionPlan(profile, { calories: 2000 });
  assert.equal(plan.estimate.bmr, 1674);
  assert.equal(plan.estimate.maintenance, 2590);
  assert.equal(plan.approach, 'maintain');
  assert.equal(plan.goal, 2000);
  assert.equal(plan.references.protein.target, 100);
  assert.equal(plan.references.carbs.target, 250);
  assert.equal(plan.references.fiber.target, 28);
});
test('Primary weight gain and secondary muscle goals affect both suggested references', () => {
  const plan = nutritionPlan({
    ...profile,
    weight: 50,
    primaryGoal: 'Gain weight',
    secondaryGoal: 'Build muscle',
    exerciseFrequency: '3–4 days',
  });
  assert.equal(plan.suggestedGoals.calories, plan.estimate.maintenance + 300);
  assert.equal(plan.suggestedGoals.protein, 80);
  assert.equal(plan.goal, null);
});
test('Healthy-range strength and muscle goals support maintenance or an explicitly chosen surplus', () => {
  const input = {
    ...profile,
    primaryGoal: 'Build muscle',
    secondaryGoal: 'Build strength',
    exerciseFrequency: '3–4 days',
  };
  const maintenance = nutritionPlan(input);
  assert.equal(maintenance.suggestedGoals.calories, maintenance.estimate.maintenance);
  assert.equal(maintenance.suggestedGoals.protein, 112);
  const surplus = nutritionPlan({ ...input, energyPreference: 'Consider a small surplus' });
  assert.equal(surplus.suggestedGoals.calories, surplus.estimate.maintenance + 150);
  assert.equal(nutritionPlan({ ...input, exerciseFrequency: 'Never' }).suggestedGoals.protein, 84);
  const loss = nutritionPlan({
    ...input,
    weight: 90,
    primaryGoal: 'Discuss gradual fat loss',
    secondaryGoal: 'Build muscle',
    energyPreference: 'Consider a small surplus',
  });
  assert.equal(loss.suggestedGoals.calories, loss.estimate.maintenance - 200);
  assert.equal(loss.approach, 'consider-deficit');
});
test('Underweight is never given a deficit and no numeric adjustment is prescribed', () => {
  const plan = nutritionPlan({
    ...profile,
    weight: 50,
    nutritionIntent: 'Discuss gradual weight loss',
  });
  assert.equal(plan.approach, 'consider-surplus');
  assert.equal(plan.goal, null);
  assert.equal(plan.deficit, undefined);
  assert.equal(
    nutritionPlan({ ...profile, weight: 90, nutritionIntent: 'Discuss gradual weight loss' })
      .approach,
    'consider-deficit',
  );
  assert.equal(nutritionPlan({ ...profile, weight: 90 }).approach, 'maintain');
});
test('Clinical, youth and breastfeeding contexts do not generate calorie estimates', () => {
  for (const context of [
    { age: 16 },
    { age: 80 },
    { pregnancyStatus: 'Pregnant' },
    { breastfeeding: true },
    { eatingConcern: true },
    { unintentionalWeightChange: true },
    { healthContext: 'Kidney condition' },
    { weight: 35 },
    { weight: 150 },
  ]) {
    const plan = nutritionPlan({ ...profile, ...context }, { calories: 2000 });
    assert.equal(plan.estimate, null);
    assert.equal(plan.references, null);
    assert.equal(plan.approach, 'professional-support');
  }
  assert.equal(nutritionPlan({ ...profile, sex: 'Prefer not to say' }).estimate, null);
});
test('Fiber sums known values while preserving an incomplete-data flag', () => {
  const result = nutrition([
    { quantity: 2, calories: 100, protein: 3, carbs: 10, fat: 2, fiber: 4 },
    { quantity: 1, calories: 50, protein: 1, carbs: 3, fat: 2, fiber: null },
  ]);
  assert.equal(result.fiber, 8);
  assert.equal(result.fiberComplete, false);
});
test('Missing Gemini configuration is an honest calculation fallback', async () => {
  let called = false;
  const result = await geminiExplanation(nutritionPlan(profile), {}, async () => {
    called = true;
  });
  assert.equal(called, false);
  assert.equal(result.available, false);
  assert.equal(result.provider, 'calculation');
});
test('Gemini receives derived estimates only and cannot change the numeric plan', async () => {
  const plan = nutritionPlan(profile, { calories: 2100 });
  let request;
  const result = await geminiExplanation(
    plan,
    { geminiKey: 'test-key', geminiModel: 'test-model' },
    async (url, options) => {
      request = options;
      assert.match(url, /test-model:generateContent$/);
      return {
        ok: true,
        json: async () => ({
          candidates: [
            {
              content: {
                parts: [
                  {
                    text: JSON.stringify({
                      summary:
                        'This is an approximate maintenance range. Your calorie goal remains your choice.',
                    }),
                  },
                ],
              },
            },
          ],
        }),
      };
    },
  );
  assert.equal(result.provider, 'Gemini');
  assert.equal(plan.goal, 2100);
  assert.equal(request.headers['x-goog-api-key'], 'test-key');
  assert.equal(request.body.includes('test-key'), false);
  const payload = JSON.parse(JSON.parse(request.body).contents[0].parts[0].text);
  assert.deepEqual(Object.keys(payload).sort(), [
    'approach',
    'estimatedMaintenance',
    'explanation',
  ]);
});
test('Gemini provider failure is reported rather than disguised as generated advice', async () => {
  await assert.rejects(
    geminiExplanation(nutritionPlan(profile), { geminiKey: 'test-key' }, async () => ({
      ok: false,
    })),
    /could not complete/,
  );
});
test('USDA mapping uses per-100g nutrient IDs and never invents missing fiber', () => {
  const food = {
    fdcId: 123,
    description: 'Test food',
    foodNutrients: [
      { nutrientId: 1008, value: 150 },
      { nutrientId: 1003, value: 5 },
      { nutrientId: 1005, value: 20 },
      { nutrientId: 1004, value: 4 },
    ],
  };
  const mapped = normalizeUsdaFood(food);
  assert.equal(mapped.serving, '100 g');
  assert.equal(mapped.fiber, null);
  assert.equal(mapped.protein, 5);
  assert.equal(normalizeUsdaFood({ ...food, foodNutrients: [] }), null);
});
