# Integration setup and verified limits

## Gemini

Create a key in [Google AI Studio](https://aistudio.google.com/apikey), add it only to backend/.env as GEMINI_API_KEY, and restart the backend. GEMINI_MODEL defaults to gemini-3.5-flash-lite and is configurable. [Official key guidance](https://ai.google.dev/gemini-api/docs/api-key).

The authenticated explanation endpoint requires consent:true. It sends derived energy estimates and coarse approach only; not account identity, health notes or journals. Numeric goals remain user-confirmed application data. The API key is sent in a server request header and never returned to the browser. Missing key returns an honest calculation fallback; provider failure returns 502 without changing records. Requests are rate limited per account.

## USDA FoodData Central

Get a key via the [official API guide](https://fdc.nal.usda.gov/api-guide/), set USDA_API_KEY server-side and restart Express. Search words are sent to USDA, not the user's profile. Online foods are per 100 g and require usable calorie/protein/carbohydrate/fat values. Missing fiber stays unknown. Without the key, saved/private custom food search continues. Search is debounced/canceled in the browser and server requests have timeouts.

## Verification

Real MongoDB/auth APIs, local search, plan previews and user-confirmed goals were tested. Gemini request privacy, structured response and errors were tested with injected HTTP responses. USDA nutrient mapping used representative data. No real Gemini/USDA keys were available, so authenticated live calls remain unverified. The standalone HTML deliberately uses the local fallback, not a hidden browser key. Visual browser QA of file:// pages is unavailable to the authoring tools.
