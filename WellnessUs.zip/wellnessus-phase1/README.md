# WellnessUs

A minimal graphite-and-mint health tracker. React/Vite, Tailwind, React Router, Recharts, Lucide and Axios power the frontend; Express, JWT, bcrypt, Mongoose and MongoDB power the backend.

## Current experience

- Overview: today's calories against the chosen budget, water, sleep duration/cycle, a meal-logging action, and a sourced daily philosopher quote. No roadmap or multi-day report appears here.
- Meals: searchable foods, quantities, automatic calories/protein/carbohydrates/fat/fiber, a per-food breakdown, optional nutrient references, maintenance context and separate 7-/30-day nutrient graphs.
- Water and sleep: logging, current-day references, history, and their own 7-/30-day charts.
- Adaptive quiz: follow-up questions about BMI, appetite, intent, activity/work pattern, food preferences, health context and routines. The final step previews an estimate when suitable and asks the user to confirm goals.
- Settings: editable references and owned-record export. Optional second-build features remain workouts, journaling and a combined report. Technical build-stage labels are not displayed in the product.

## Install and run

Requires Node.js 22.13+ with npm and MongoDB 7/8 (or Docker Desktop).

```sh
npm install
npm run setup
```

Copy `backend/.env.example` to `backend/.env` and `frontend/.env.example` to `frontend/.env`. Set a random JWT_SECRET of at least 32 characters and a valid MongoDB URI. The example secret is deliberately rejected. Keep environment files out of Git.

Start your local MongoDB service, or use `docker compose up -d`. Then:

```sh
npm run seed
npm run dev
```

Open http://localhost:5173. API: http://localhost:4000. Use localhost consistently. The included Docker database binds only to localhost and retains records in a named volume; do not expose its unauthenticated local configuration to other machines.

The idempotent seed adds 24 estimated common foods including Indian foods, now with fiber. Rerun it to update an older library. It preserves personal records and never seeds fake tracking statistics. Historical meal snapshots are not rewritten; missing fiber remains unknown.

## Optional integrations

In the server-only backend environment file, configure GEMINI_API_KEY, GEMINI_MODEL (default gemini-3.5-flash-lite), and USDA_API_KEY. Restart Express afterward. Never place keys in frontend code, a VITE_ variable, chat messages or Git. See INTEGRATIONS.md.

Gemini is requested only when the user clicks the explanation action. Only the derived estimate and coarse approach are sent to Google, not name, email, health notes or journals. Application arithmetic remains the source of numeric estimates; AI cannot overwrite chosen goals. Without a key, the app labels its calculation fallback honestly.

Food search always covers permitted saved foods and custom entries. With USDA_API_KEY it also queries FoodData Central. Online results are per 100 g: 150 g is 1.5 servings, 40 g is 0.4. Local foods use their stated cup/bowl/piece serving. Missing fiber stays unknown. Provider errors retain the local workflow and never change saved records.

No actual provider keys were available during authoring. Request construction, privacy boundaries, nutrient mapping and fallbacks were tested; authenticated live Gemini/USDA requests were not made.

## Maintenance and nutrient estimates

Suitable adult profiles use Mifflin–St Jeor resting energy expenditure times an approximate activity factor (1.2, 1.375, 1.55 or 1.725). The displayed ±10% band illustrates uncertainty; it is not a validated confidence interval. The final quiz step combines primary and secondary goals with the maintenance estimate, pre-fills suggested calorie/protein references, and lets the user change or clear them before confirmation. No automatic deficit, surplus amount or weight-loss target is applied. Underweight profiles are never given a deficit suggestion.

No automatic energy estimate is generated for under-18 users, ages beyond the original adult sample, pregnancy, breastfeeding, eating-related concerns, unexplained weight change, or recorded health considerations. Declining equation sex also leaves the estimate unavailable. Adult BMI categories are not applied to minors or pregnancy.

For suitable adults aged 19+, optional nutrient examples follow the chosen calorie goal. Balanced: 20% protein/50% carbohydrate/30% fat. Protein awareness: 25%/45%/30%. Adult reference ranges are also displayed: protein 10–35%, carbohydrate 45–65%, fat 20–35%. Fiber uses 14 g per 1000 kcal. A saved protein goal overrides the example split. These are transparent planning guides, not individual prescriptions or deficiency diagnoses.

References: [Mifflin–St Jeor](https://pubmed.ncbi.nlm.nih.gov/2305711/), [adult nutrient ranges](https://www.ncbi.nlm.nih.gov/books/NBK221374/), [fiber reference](https://health.gov/sites/default/files/2019-09/15-Appendix-E-3.pdf), [NIDDK context](https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner).

## Time and history

Meals/water are server-stamped at the current instant in the browser's validated IANA timezone. Edits preserve the original time/day. History filters do not backdate new entries. Daily totals and the quote update at local midnight. Sleep belongs to its wake-up date and handles overnight sessions shorter than 24 hours. The quotes rotate through a small sourced collection, with attribution links.

## Build, tests and variants

```sh
npm test
npm run build
npm start
```

For a local single-server preview, set CLIENT_ORIGIN to http://localhost:4000 and keep NODE_ENV=development. Actual deployment requires HTTPS, production cookie settings, an authenticated database and backups.

33 tests cover actual-MongoDB auth/CRUD/isolation, quiz/goal confirmation, BMI/energy/fiber calculations, current timestamps, local midnight, provider request privacy, errors and nutrient mapping. Tests normally use temporary MongoDB; set TEST_DB_PATH to a writable directory if Windows temporary-folder restrictions interfere. Never point TEST_MONGODB_URI at personal records.

Internal build settings remain PROJECT_PHASE and VITE_PROJECT_PHASE (both 1 for the core application, both 2 to add workouts/journal/combined reports). Both builds include per-tracker 7-/30-day charts. Stage labels are confined to technical configuration and assessment documentation. Restart/rebuild after changing settings.

The modular source is organized into frontend components/pages/layouts/hooks/context/services/utils and backend config/models/controllers/routes/middleware/services/utils, plus backend tests. JWT cookies are HttpOnly/SameSite, bcrypt hashes passwords, and APIs enforce ownership, validation, origin checks and rate limits. Data persists in MongoDB. See API.md and VERIFICATION.md.

## Browser demo

WellnessUs-Demo.html is self-contained and uses the real interface with a browser-only storage adapter. It includes the quiz, calculated maintenance, chosen goals, food/fiber tracking and per-tracker charts. It cannot securely call a keyed server API by itself, so Gemini uses an explicitly labeled calculation fallback and food search uses the bundled library. No real account/password is created. Use test information and refresh an already open tab after replacing the file.

Calculator scope: extreme adult BMI values (below 16 or at/above 40), or an estimated maintenance outside 1200–6000 kcal/day, are also held for individual review. These are conservative application guardrails, not diagnostic thresholds or suggested intake limits.

## Latest logic refinements

Sleep is limited to two sessions per wake-up date and 1440 combined minutes, including edits/date moves. New writes are validated on the server and in the demo/form. A per-user queue serializes concurrent sleep writes in the documented single Express process. This is a single-instance local application; before running several backend replicas, replace that queue with a transactional/distributed database constraint. Older invalid records are preserved for review rather than silently deleted; invalid daily totals are not presented as valid sleep statistics.

The daily quote appears above the overview heading and metrics. The quiz hides reproductive-context questions for the Male equation-sex selection and clears stale reproductive answers when that selection changes. It asks a primary and optional secondary goal, offering BMI-appropriate muscle, strength, modest-gain, routine or supported fat-loss choices. Duplicate and contradictory goals are rejected.

Goal-based calorie examples are reviewable before saving: selected underweight weight gain uses an illustrative 300 kcal surplus, modest adult gain/muscle surplus uses 150 kcal when selected, and an explicitly chosen supported fat-loss goal in a suitable above-range profile uses a 200 kcal deficit example. BMI alone does not apply an adjustment. Clinical/youth exclusions remain in place.

Protein examples use 1.6 g/kg for muscle/strength with current weekly activity, 1.2 g/kg when getting started or focused on gain, and 0.8 g/kg for general maintenance; the example is bounded by the calorie reference. The user confirms an editable protein target separately. A saved target overrides percentage-based examples. Protein alone does not guarantee muscle gain. [Exercise/protein context](https://pmc.ncbi.nlm.nih.gov/articles/PMC5477153/) and [gradual weight-gain context](https://www.nhs.uk/live-well/healthy-weight/managing-your-weight/healthy-ways-to-gain-weight/).
