# WellnessUs API

Base: `/api`. Authenticated requests retain the HttpOnly `wellnessus_session` cookie. JSON success is `{data: ...}`; failures are `{error: "Readable message"}`. Lists additionally include `total`, `page`, `limit`.

## Shared endpoints

| Method  | Route          | Purpose                                                                   |
| ------- | -------------- | ------------------------------------------------------------------------- |
| POST    | /auth/register | `{name,email,password}` → account/session, onboarding incomplete          |
| POST    | /auth/login    | `{email,password}` → session                                              |
| GET     | /auth/me       | Own public account fields                                                 |
| POST    | /auth/logout   | Clear cookie and revoke all account sessions                              |
| GET     | /profile       | Own health profile, calculated BMI and roadmap; null before quiz          |
| PUT     | /profile       | Save quiz, mark onboarding complete, recalculate BMI/roadmap              |
| GET     | /roadmap       | Own rule-based roadmap, or null before quiz                               |
| GET/PUT | /goals         | Read/save complete calorie/water/sleep/protein/weekly-activity references |
| GET     | /foods         | Shared food library plus own private custom foods                         |
| POST    | /foods         | Add private per-serving food values                                       |
| GET     | /health        | Public readiness response                                                 |

Profile fields: `age`, `sex` (Female, Male, Intersex, Prefer not to say), `height` (cm), `weight` (kg), `pregnancyStatus` (Not applicable, Not pregnant, Pregnant, Prefer not to say), optional `healthContext` (maximum 500 chars), `unintentionalWeightChange` (boolean), `timeZone` (IANA), `objective`, `activity`, `averageSleep`, `mealConsistency`, `hydrationConsistency`. The existing exercise/preference fields remain accepted for compatibility and Phase 2. All enum choices are defined in `backend/src/utils/validation.js`.

Goals payload example:

```json
{ "water": 2000, "sleep": 8, "calories": 2100, "protein": null, "weeklyWorkouts": 3 }
```

Calories/protein can be null. No calorie reference is generated from BMI. Weekly activity is shown only in Phase 2.

## Tracking endpoints

Each enabled module supports GET/POST `/:module` and GET/PUT/DELETE `/:module/:id`. POST returns 201. PUT expects the full editable payload. Every query is scoped to the authenticated user. Foreign records return 404.

Phase 1 modules: `meals`, `water`, `sleep`.
Phase 2 adds: `workouts`, `journal`. Progress is computed from those owned records; it does not fabricate a separate score.

List filters: inclusive `from`/`to` calendar dates, `page` (default 1), `limit` (default 200, maximum 500). Journal supports literal case-insensitive `search` against title/content. The frontend follows pagination for reports/export.

### Current-time meal logging

```json
{
  "timeZone": "Asia/Kolkata",
  "type": "Lunch",
  "items": [
    {
      "name": "Dal",
      "serving": "1 cup",
      "quantity": 1.5,
      "calories": 210,
      "protein": 12,
      "carbs": 32,
      "fat": 4
    }
  ]
}
```

Meal names: Breakfast, Lunch, Dinner, Snacks. One to 50 foods; per-serving nutrition is multiplied by quantity on the server. Estimated totals are returned as `totals`.

### Current-time water logging

```json
{ "timeZone": "Asia/Kolkata", "amount": 250 }
```

Amount is 1–5000 ml per entry. For meals and water, the server sets `recordedAt` to its current UTC instant and calculates `date` in the validated IANA timezone. A valid historical `date` is accepted only for backward-compatible clients and ignored when creating these entries. Direct `recordedAt` input is rejected. Updating keeps the original `recordedAt`, `date` and `timeZone`. Invalid timezones return 422. Missing timezone defaults to UTC; the UI always sends the browser's detected timezone.

### Sleep

```json
{ "date": "2026-11-03", "bedtime": "22:30", "wakeTime": "06:30", "notes": "Rested well" }
```

Date is the wake-up date. Times use 24-hour HH:mm; earlier wake time means overnight. Equal times are rejected. Returned `hours` is rounded to two decimals. Multiple sessions on the same date are summed.

### Phase 2 workout

```json
{
  "date": "2026-11-03",
  "type": "Strength",
  "duration": 30,
  "exercises": [{ "name": "Squat", "sets": 3, "reps": 10 }],
  "notes": "Comfortable pace"
}
```

Types: Strength, Walking, Running, Cycling, Yoga, Swimming, Other. Exercises are optional. Input bounds are validation rules, not prescriptions for exercise volume.

### Phase 2 journal

```json
{ "date": "2026-11-03", "title": "A moment today", "content": "Enjoyed a walk.", "mood": "Good" }
```

Mood: Great, Good, Okay, Low, Difficult. Title maximum 150 characters, content maximum 20000. User ownership is checked on every operation.

## Errors and access

422 invalid inputs; 401 absent/invalid/expired login; 403 browser origin rejected; 404 missing/foreign/unavailable-phase resource; 409 duplicate email; 429 rate limit; 500 generic internal failure. Unknown request keys, including caller-supplied ownership IDs and derived timestamps, are rejected. Passwords need at least 10 characters and no more than 72 UTF-8 bytes.

## Updated nutrition endpoints

GET /nutrition-plan returns owned deterministic energy/goal/nutrient context. POST /nutrition-plan/preview validates a profile draft without saving it. POST /nutrition-plan/explain accepts consent:true and an optional validated profile draft, requesting a Gemini explanation or explicitly labeled fallback. It never changes numeric goals. GET /foods/search?q=... returns permitted local foods and optional normalized USDA results, with onlineConfigured and provider warnings.

New quiz fields: breastfeeding, eatingConcern, nutritionIntent, dietPreference, workPattern, appetite, mealFrequency. A profile save with applyGoals:true plus calorieGoal (number or null), waterGoal and sleepGoal explicitly confirms the user's references. These fields update the owned goal document, not ownership or health-profile metadata.

Foods accept fiber (grams per serving, or null). Meal totals include known fiber and fiberComplete. Missing fiber is not a measured zero. Provider results use a 100 g serving; quantities scale every nutrient. Roadmap endpoints remain for source compatibility but have no navigation or screen in the current website.

Sleep writes now return 422 if a wake-up date would contain more than two sessions or more than 1440 exact minutes. Updates exclude the original entry from the total, and moves validate the destination day. Concurrent writes are serialized per user in the single-process local backend.

Profiles accept primaryGoal, secondaryGoal and energyPreference. Profile saves with applyGoals:true can include proteinGoal (number or null), which is written to the owned goal record. Duplicate/conflicting selections are rejected. The plan response includes suggestedGoals with calorie/protein examples, rationale and sources; only the user's final confirmation saves targets.
